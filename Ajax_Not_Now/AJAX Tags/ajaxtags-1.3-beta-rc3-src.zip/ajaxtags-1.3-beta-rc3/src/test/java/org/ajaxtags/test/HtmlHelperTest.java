/**
 * Copyright 2007 Jens Kapitza
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.test;

import static junit.framework.Assert.*;

import org.ajaxtags.helpers.AjaxHtmlHelper;
import org.junit.Before;
import org.junit.Test;

/**
 * Simple Testcase for AjaxHtmlHelper
 * 
 * @author Jens Kapitza
 * @version $Revision: 1.1 $ $Date: 2007/06/20 20:55:56 $ $Author: jenskapitza $
 */
public class HtmlHelperTest {

	private String html;
	private String tagcontent, tagcontentdiv;

	@Before
	public void setUp() {
		tagcontent = "das ist ein test";
		tagcontentdiv = tagcontent + " DIV";
		html = "<html><body><div class='klasse' id='id'>" + tagcontentdiv
				+ "</div><a>" + tagcontent + "</a></body></html>";
	}

	@Test
	public void tagContent() {
		assertEquals(AjaxHtmlHelper.getTagContent(html, "a"), tagcontent);
		assertEquals(AjaxHtmlHelper.getTagContent(html, "div", "klasse"),
				tagcontentdiv);
		assertEquals(AjaxHtmlHelper.getTagContentById(html, "id"),
				tagcontentdiv);
	}

}
