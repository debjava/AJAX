package com.proajax.chapt7.service;

import java.util.List;

public interface HelloWorldService {

    public String getCurrentDateString();
    
    public List<String> getUnorderedList();
}
