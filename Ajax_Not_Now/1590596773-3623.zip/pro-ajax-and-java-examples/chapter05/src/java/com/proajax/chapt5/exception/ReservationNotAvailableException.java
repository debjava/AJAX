package com.proajax.chapt5.exception;

public class ReservationNotAvailableException extends java.lang.Exception {
    
}
