/*
 * ShowPodcast.java
 *
 * Created on March 4, 2006, 1:35 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.proajax.chapt6;

import org.apache.tapestry.html.BasePage;

/**
 *
 * @author nate
 */
public abstract class ShowPodcast extends BasePage {
    
    public abstract void setPodcast(Podcast podcast);
}
