<?php
/*
============================================================
Project: End-to-End-Ajax application development

Purpose: This is an example scenario to be used in
 an IBM developerWorks article.

Last modified: May/17/2007.

This module is the REST service request handler for the
server-side of the bank scenario. It receives the 
REST (HTTP POST) requests from the single-page based 
bank teller browser clients. It dispatches different 
request requests to different bank logic functions.
It also sends and receives application-specific data
in a previously agreed JSON format. 
============================================================
*/
   // Get the other required PHP modules.
   // JSON.php is an open source JSON parser in PHP.
   // It can be obtained from: : http://mike.teczno.com/JSON/JSON.phps 
   require_once("JSON.php");
   // Bank Logic module has all the core bank teller server-side functions.
   require_once("BankLogic.php");
   // GetStockPrice is a Web service proxy client to a remote Web service.
   require_once("GetStockPrice.php");
   
   // Define all the constants that will be used here.
   define ("BANK_TELLER_COMMAND_KEY", "Bank_Teller_Command");
   define ("BANK_TELLER_POST_DATA_KEY", "Post_Data");
   define ("GET_ALL_ACCOUNTS_INFO", "Get_All_Accounts_Info");
   define ("DEPOSIT_TO_ACCOUNT", "Deposit_To_Account");
   define ("DEBIT_FROM_ACCOUNT", "Debit_From_Account");
   define ("GET_STOCK_PORTFOLIO_VALUE", "Get_Stock_Portfolio_Value");
   
   // XHTML form data from the bank teller Ajax browser client will be
   // available in one of the PHP superglobals 
   // i.e. $_REQUEST associative array.
   // Each REST request from the client will have two key-value pairs.
   // First one is the bank teller command that tells if the client
   // wants to perform deposit, debit, portfolio value etc.
   // The second key-value pair is the application specific data sent as
   // JSON-formatted string. 
   $bankTellerCommand = $_REQUEST[BANK_TELLER_COMMAND_KEY];
   $bankTellerPostData = $_REQUEST[BANK_TELLER_POST_DATA_KEY];
   
   // Using JSON in PHP is as easy as it can get.
   // Instantiate the JSON parser (available through JSON.php)
   $json = new Services_JSON();
   // In one statement, convert the JSON formatted text to
   // an equivalent PHP class struture. That is it.
   $bankTellerInput = $json->decode($bankTellerPostData);
   $responseToBeSent = "";
   $bankActionResult = null;
   
   // Switch through the bank teller command issued by the browser client.
   switch($bankTellerCommand) {
      case GET_ALL_ACCOUNTS_INFO:
         // Go and get all the account information stored in the database.
         $bankActionResult = getAllAccountInformation();
         break;
         
      case DEPOSIT_TO_ACCOUNT:
         // Perform the deposit account transaction.
         // Pass the account holder name and the deposit amount as 
         // sent by the browser client. Third parameter of 1 indicates DEPOSIT.
         // This function is available in BankLogic.php
         $bankActionResult = 
            accountTransaction(
               $bankTellerInput->accountHolderName,
               $bankTellerInput->amount, 1);
         break;
         
      case DEBIT_FROM_ACCOUNT:
         // Perform the debit account transaction.
         // Pass the account holder name and the debit amount as 
         // sent by the browser client. Third parameter of 2 indicates DEBIT.
         // This function is available in BankLogic.php         
         $bankActionResult = 
            accountTransaction(
               $bankTellerInput->accountHolderName,
               $bankTellerInput->amount, 2);         
         break;
         
      case GET_STOCK_PORTFOLIO_VALUE:
         // Perform the "Update Stock Portfolio Value" transaction.
         // This will require going out on the Internet to a remote Web service.
         // This function is available in GetStockPrice.php
         $bankActionResult = 
            getStockPortfolioValue($bankTellerInput->accountHolderName);
         break;
         
      default:
         // Invalid Bank teller command.
         $bankActionResult["ResultCode"] = 1;
         $bankActionResult["ResultMsg"] = "Invalid Teller Command";
   } // End of switch($bankTellerCommand)
   
   // We completed everything that the client asked us to do.
   // Let us return the final results in JSON formatted text.
   // It takes one line of code in PHP to convert a 
   // PHP associative array data structure into JSON formatted text.
   $responseToBeSent = $json->encode($bankActionResult);
   // Set the HTTP header to indicate that we are sending JSON plain text data.
   // There are also efforts underway at this time (MAY/2007) to define a 
   // new content type called text/json.
   header("Content-Type: text/plain");      
   // That is it. Return the JSON formatted response in 
   // RESTful way back to the browser now.
   echo($responseToBeSent);
?>
