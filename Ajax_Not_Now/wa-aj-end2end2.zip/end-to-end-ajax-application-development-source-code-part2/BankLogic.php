<?php
/*
============================================================
Project: End-to-End-Ajax application development

Purpose: This is an example scenario to be used in
 an IBM developerWorks article.

Last modified: May/11/2007.

This PHP module provides the core bank teller logic
required to access the customer related data from the 
database. These functions can be called by other PHP
modules present in the Bank scenario. All the logic
involved in bank teller actions are divided into these
three core functions.

 a) Get all account information
 b) Process Transaction (deposit or debit)
 c) Compute stock portfolio value

It uses direct mysqli functions to access the database as 
opposed to the PHP PDO functions. 
============================================================
*/
   // These globals will be used to hold the following values:
   // 1) $link is for storing the database connection object.
   // 2) $dbResult is for storing the db query result object.
   // 3) $finalResult is an associative array where the results
   //    from individual bank teller actions are packaged and
   //    returned to the caller.
   global $link, $dbResult, $finalResult;

   /*
   ============================================================
   Function: connect_to_db

   Last modified: May/11/2007.
	
   This function connects to the BankDB MySQL database.
   If the connection attempt is successful, it stores the 
   connection object in a global scoped variable and
   returns true. 
   If the connection attempt is not successful, then it
   returns false.
   ============================================================ 
   */
   function connect_to_db() {
      // We will use these global scoped variables here.
      global $link, $dbResult, $finalResult;
		
      // Initialize the variables.
      $link = null;
      $dbResult = null;
      $finalResult = null;
		
      // Do a mysqli connect to the local BankDB database using
      // proper credentials.
      $link = mysqli_connect("localhost", "root", "webtech", "bankdb");

      // Check if DB connection worked.
      if (mysqli_connect_errno()) {
         // It looks like there is some problem.
         // Get the MySQL error number and the error string.
         $resultMsg = "DB connection error: " . mysqli_connect_errno() .
            " [" . mysqli_connect_error() . "]";
         // Store the results in an associative array.
         // Set the result of the operation as not a successful one.
         $finalResult["ResultCode"] = 1;
         // Set the result message.
         $finalResult["ResultMsg"] = $resultMsg;
         // Return false to indicate the DB connection failure.
         return (false);
      } else {
         // DB connection is good.
         return(true);		
      } // End of if (mysqli_connect_errno())
   } // End of function connect_to_db

   /*
   ============================================================
   Function: close_connection_to_db

   Last modified: May/11/2007.

   This function closes the connection made earlier to the
   BankDB database.
   ============================================================ 
   */	
   function close_connection_to_db() {
      // We will use these globally scoped variables.
      global $link, $dbResult;
	
      // Close the connection if we have an active
      // DB connection object.
      if ($link != null) {
         if (($dbResult != null) && (is_object($dbResult))) {
            // If the DB result contains query data object, free it now.
            mysqli_free_result($dbResult);
            $dbResult = null;
         } // End of if ($dbResult != null)
			
         // Time to close the DB connection.
         mysqli_close($link);
         // Set the connection object variable to null.
         $link = null;			
      } // End of if ($link != null)
   } // End of function close_connection_to_db

   /*
   ============================================================
   Function: getAllAccountInformation
	
   Last modified: May/11/2007.
	
   This function reads all the account information stored in
   the BankDB and returns them in an associative array.
   ============================================================ 
   */			
   function getAllAccountInformation() {
      // We will use these globally scoped variables.
      global $link, $finalResult, $dbResult;
	
      // Get a connection to the BankDB.
      $result = connect_to_db();
	
      // If db connection failed, return now.
      if ($result == false) {
         return ($finalResult);
      } // End of if ($result == false)
		
      // Make an SQL statement to query all rows in the account table.
      $queryStr = "Select * from account";
      // Make the SQL query.
      $dbResult = mysqli_query($link, $queryStr);
		
      // Process if there are any query errors.
      if (mysqli_errno($link)) {
         // Close the connection first.
         close_connection_to_db();		
         // Set the error message in the final result assoc. array.	
         $resultMsg = "DB read error: " . mysqli_errno($link) .
            " [" . mysqli_error($link) . "]";
         // Set the application specific return code as FAILURE.
         $finalResult["ResultCode"] = 1;				
         $finalResult["ResultMsg"] = $resultMsg;
         // Return the final result.
         return ($finalResult);
      } // End of if (mysqli_errno($link))
		
      // Get the number of rows queried.
      $rowCount = mysqli_num_rows($dbResult);
	
      // If the database is empty, return now.
      if ($rowCount <= 0) {
         // Close the connection first.
         close_connection_to_db();
         // Set the return code and return message.
         $finalResult["ResultCode"] = 1;				
         $finalResult["ResultMsg"] = "No accounts were found in BankDB.";
         // Return the final result.
         return ($finalResult);			
      } // End of if ($rowCount <= 0)

      // Set the counter to 0.
      $cnt = 0;
      // Create an array to hold all the fields from each row.
      $accountInfo = array();

      // From the query result set, fetch data fields from each row.
      while($row = mysqli_fetch_assoc($dbResult)) {
         // Initialize it to null.
         $data = null;
         // Create an associative array on the fly and store the
         // individual data fields read from the current database row.
         $data["AccountHolderName"] = $row["AccountHolderName"];
         $data["AccountNumber"] = $row["AccountNumber"];
         $data["CheckingBalance"] = doubleval($row["CheckingBalance"]);
         $data["StockName"] = $row["StockName"];
         $data["StockQuantity"] = intval($row["StockQuantity"]);
         $data["StockValue"] = doubleval($row["StockValue"]);
         // Now, store the entire associative array in to a regular array.
         $accountInfo[$cnt++] = $data;
      } // End of while($row = mysqli_fetch_assoc($dbResult))
		
      // We finished reading all the account information from the database.
      // Set the final result code as success.
      $finalResult["ResultCode"] = 0;
      // Set the final result message as success.
      $finalResult["ResultMsg"] = "ReadAllAccountsInfoFromDB successful";
      // Make the entire array holding all the account information into the
      // final result associative array.
      // $finalResult is an associative array containing an
      // regular array which in turn contains several associative arrays as
      // its elements.
      $finalResult["AccountInfo"] = $accountInfo;
      // Close the DB connection.	
      close_connection_to_db();	
      // Return the final result array now.
      return($finalResult);		
   } // End of function getAllAccountInformation

   /*
   ============================================================
   Function: accountTransaction

   Last modified: May/11/2007.
	
   This function performs the bank teller account transaction.
   This function takes the account holder name, an amount and
   the transaction type as function parameter.
   The transaction type is 1 for deposit into checking account.
   The transaction type is 2 for debit from a checking account.
   After the transaction is done, it returns the snapshot of 
   the account before this transaction and another snapshot of
   the account after this transaction.
   ============================================================ 
   */	
   function accountTransaction($accountHolderName, $amount, $transactionType) {
      // We will use these globally scoped variables.
      global $link, $finalResult, $dbResult;
      // Get a database connection.
      $result = connect_to_db();
		
      // If the connection failed, return now.
      if ($result == false) {
         return ($finalResult);
      } // End of if ($result == false)

      // Make an SQL statement to read a particular account data for a 
      // given account holder name.
      $queryStr = "Select * from account where AccountHolderName='$accountHolderName'";
      // Perform the SQL query.
      $dbResult = mysqli_query($link, $queryStr);
	
      // Did you encounter a DB error?
      if (mysqli_errno($link)) {
         // Close the connection now.
         close_connection_to_db();
         // Set the DB error message.
         $resultMsg = "DB read error: " . mysqli_errno($link) .
            " [" . mysqli_error($link) . "]";
         // Set the application-specific result code.
         $finalResult["ResultCode"] = 1;				
         // Set the result message.
         $finalResult["ResultMsg"] = $resultMsg;
         // Return the associative array with the error result.
         return ($finalResult);
      } // End of if (mysqli_errno($link))

      // How many rows were read from the DB?
      $rowCount = mysqli_num_rows($dbResult);
	
      // If no rows are obtained from DB, return now.
      if ($rowCount <= 0) {
         // Close the connection now.
         close_connection_to_db();
         // Setup the return value as not a successful one.
         $finalResult["ResultCode"] = 1;				
         $finalResult["ResultMsg"] = "No accounts were found in BankDB.";
         // Return the final result.
         return ($finalResult);			
      } // End of if ($rowCount <= 0)

      // Store a record with the current checking balance.
      // Create an array to hold the pre-transaction and 
      // post-transaction acoount snapshots.
      $accountInfo = array();		
      // Fetch the query result as an associative array.
      $row = mysqli_fetch_assoc($dbResult);		
      $data = null;
      // Record the filed values from the database row into
      // a new associative array.
      $data["AccountHolderName"] = $row["AccountHolderName"];
      $data["AccountNumber"] = $row["AccountNumber"];
      $data["PreviousCheckingBalance"] = doubleVal($row["CheckingBalance"]);
      $data["StockName"] = $row["StockName"];
      $data["StockQuantity"] = intval($row["StockQuantity"]);
      $data["StockValue"] = doubleVal($row["StockValue"]);
      // Store the pre-transaction account snapshot into a regular array.
      $accountInfo[0] = $data;

      // Initialize the variables.
      $newBalance = 0.0;
      // Since we are doing a transaction that changes the
      // checking balance, we need to update the DB later.
      $updateDB = true;

      if ($transactionType == 1) {
         // It is deposit.
         // Ensure that user wants to deposit an amount greater than 0.
         if ($amount > 0) {
            $newBalance = doubleval($data["PreviousCheckingBalance"]) + $amount;
         } else {
            // Deposit amount is 0. There is no need to do a database update.
            $updateDB = false;
            $newBalance = doubleval($data["PreviousCheckingBalance"]);
         } // End of if ($amount > 0)
      } else if ($transactionType == 2) {
         // It is debit.
         // Ensure that the user wants to debit an amount greater than 0 and
         // the amount is less than the money available in the checking account.
         if (($amount > 0) &&
            ($amount < doubleval($data["PreviousCheckingBalance"]))) {
            $newBalance = doubleval($data["PreviousCheckingBalance"]) - $amount;	
         } else {
            // Debit amount is either 0 or it is bigger than a allowed value.
            $updateDB = false;
            $newBalance = doubleval($data["PreviousCheckingBalance"]);
         }
      } // End of if ($transactionType == 1)
		
      // Bank teller transaction is completed now.
      // Life is good. Send the result back.
      $finalResult["ResultCode"] = 0;
      $finalResult["ResultMsg"] = "AccountTransaction successful.";

      // If we modified the current checking balance because of a
      // deposited or debited amount, then update the database.
      if ($updateDB == true) {
         // Prepare an SQL Update statement.
         $updateStr = "update account set CheckingBalance=$newBalance " .
            "where AccountHolderName='$accountHolderName'";

         // Execute the update query.
         $dbResult = mysqli_query($link, $updateStr);

         // See if there are any DB errors?
         if (mysqli_errno($link)) {
            // Close the connection to the database.
            close_connection_to_db();				
            // Prepare the error message to be returned.
            $resultMsg = "DB write error: " . mysqli_errno($link) .
               " [" . mysqli_error($link) . "]";
            $finalResult["ResultCode"] = 1;
            $finalResult["ResultMsg"] = $resultMsg;
            // Return the error message.
            return ($finalResult);
         }
					
         if ($dbResult == true) {
            // All fine.
            // Prepare to send back the result of this operation.
            $finalResult["ResultCode"] = 0;
            $finalResult["ResultMsg"] = 
               "New balance for $accountHolderName has been stored in DB.";
         } else {
            $finalResult["ResultCode"] = 1;
            $finalResult["ResultMsg"] = 
            "New balance for $accountHolderName could not be stored in DB.";
            // Return the final result that has an error.
            return($finalResult);
         } // End of if ($dbResult == true)				
      } // End of if ($updateDB == true)
		
      // We already stored the pre-transaction account snapshot in an
      // array at the top of this function.
      // Store a second record that will have the updated checking balance.
      $data = null;
      $data["AccountHolderName"] = $row["AccountHolderName"];
      $data["TransactionAmount"] = $amount;
      $data["AccountNumber"] = $row["AccountNumber"];
      $data["NewCheckingBalance"] = $newBalance;
      $data["StockName"] = $row["StockName"];
      $data["StockQuantity"] = intval($row["StockQuantity"]);
      $data["StockValue"] = doubleval($row["StockValue"]);
      $accountInfo[1] = $data;		
      $finalResult["AccountInfo"] = $accountInfo;	
      // Close the DB connection.
      close_connection_to_db();	
      // Return the final result.
      return($finalResult);				
   } // End of function accountTransaction.

   /*
   ============================================================
   Function: portfolioValue
	
   Last modified: May/11/2007.
	
   This function stores the current portfolio value of a 
   given account holder to the database. It takes the 
   account holder name and the current stock price as input
   arguments. It reads the currently held position (in the
   Bank scenario, every account holder owns only a single
   company's stock. It is done to make the task simpler.)
   and computes the current market value. Then it updates
   the database with the new total stock value.
   ============================================================ 
   */		
   function portfolioValue($accountHolderName, $stockPrice) {
      // We will use the globally scoped variables. 
      global $link, $finalResult, $dbResult;

      // Connect to the MySQL BankDB database.
      $result = connect_to_db();
	
      // If error in connecting to the DB, return now.
      if ($result == false) {
         return ($finalResult);
      } // End of if ($result == false)

      // Prepare the query string to get account info for a given account holder.
      $queryStr = "Select * from account where AccountHolderName='$accountHolderName'";
      // Execute the MySQL query.
      $dbResult = mysqli_query($link, $queryStr);
	
      // Are there any errors?
      if (mysqli_errno($link)) {
         // Error there. Close the db connection. 
         close_connection_to_db();
         // Prepare error message to be returned.
         $resultMsg = "DB read error: " . mysqli_errno($link) .
            " [" . mysqli_error($link) . "]";
         $finalResult["ResultCode"] = 1;				
         $finalResult["ResultMsg"] = $resultMsg;
         // Return the error.
         return ($finalResult);
      } // End of if (mysqli_errno($link))

      // Did we read any rows from the DB? 
      $rowCount = mysqli_num_rows($dbResult);
	
      // If there are no matching rows in DB, return now.
      if ($rowCount <= 0) {
         // Close the DB connection.
         close_connection_to_db();
         $finalResult["ResultCode"] = 1;				
         $finalResult["ResultMsg"] = "No accounts were found in BankDB.";
         // Return the final result.
         return ($finalResult);			
      } // End of if ($rowCount <= 0)

      // Store a record with the current portfolio value.
      // Allocate an array to store the pre-transaction and the
      // post-transaction account snapshots.
      $accountInfo = array();		
      // Do a database fetch to get the results as an associative array.
      $row = mysqli_fetch_assoc($dbResult);		
      // Store the data fields of a row to an associative array.
      $data = null;
      $data["AccountHolderName"] = $row["AccountHolderName"];
      $data["AccountNumber"] = $row["AccountNumber"];
      $data["CheckingBalance"] = doubleval($row["CheckingBalance"]);
      $data["StockName"] = $row["StockName"];
      $data["StockQuantity"] = intval($row["StockQuantity"]);
      $data["PreviousPortfolioValue"] = doubleval($row["StockValue"]);
      // Store the associative array in a regular array.
      $accountInfo[0] = $data;

      // Calculate the portfolio value.
      $finalResult["ResultCode"] = 0;
      $finalResult["ResultMsg"] = "PortfolioValue successfully calculated.";
      $newPortfolioValue = intval($row["StockQuantity"]) * doubleval($stockPrice);
	
      // Since the stock portfolio value has changed, update it in DB.
      $updateStr = "update account set StockValue=$newPortfolioValue " .
         "where AccountHolderName='$accountHolderName'";

      // Perform an SQL update.
      $dbResult = mysqli_query($link, $updateStr);

      // Check if there are any DB errros.
      if (mysqli_errno($link)) {
         // Close the connection to DB.
         close_connection_to_db();		
         // Prepare the error message to returned.		
         $resultMsg = "DB write error: " . mysqli_errno($link) .
            " [" . mysqli_error($link) . "]";
         $finalResult["ResultCode"] = 1;
         $finalResult["ResultMsg"] = $resultMsg;
         // Return the error messsage.
         return ($finalResult);
      } // End of if (mysqli_errno($link))
			
      if ($dbResult == true) {
         // All fine.
         // Prepare the success message to be returned.
         $finalResult["ResultCode"] = 0;
         $finalResult["ResultMsg"] = 
            "New stock value for $accountHolderName has been stored in DB.";
      } else {
         $finalResult["ResultCode"] = 1;
         $finalResult["ResultMsg"] = 
            "New stock value for $accountHolderName could not be stored in DB.";
         // Update failed. Hence return the error result.
         return($finalResult);
      } // End of else in if ($dbResult == true)				
		
      // Store a second record that will have the updated portfolio value.
      // We have already stored the pre-transaction account snapshot in an array.
      // Let us store the post-transaction account snapshort also there.
      $data = null;
      $data["AccountHolderName"] = $row["AccountHolderName"];
      $data["AccountNumber"] = $row["AccountNumber"];
      $data["CheckingBalance"] = doubleval($row["CheckingBalance"]);
      $data["StockName"] = $row["StockName"];
      $data["CurrentStockPrice"] = doubleval($stockPrice);
      $data["StockQuantity"] = intval($row["StockQuantity"]);
      $data["NewPortfolioValue"] = $newPortfolioValue;
      // Store the associative array in a regular array.
      $accountInfo[1] = $data;		
      $finalResult["AccountInfo"] = $accountInfo;	
      // Close the DB connection and return the result.
      close_connection_to_db();	
      return($finalResult);				
   } // End of function portfolioValue.	
?>
