Hello and welcome to the source code for the book 
Practical Ajax Projects with Java by Frank W. Zammetti!

For each chapter in the book, you will find a directory here.  The 
first three chapters have the code shown as examples in the chapter (at 
least the more lengthy bits of code... many of the smaller snippets are
not included here).  

For chapter 4 through 10, you will find a WAR file that you should be 
able to drop into the container of your choice and try it out right
away without any further work on your part.  You will also find a 
directory that matches the name of the webapp.  This is the webapp in 
exploded format with all the source code.  If you wish to recompile, 
use the Ant build script found in xxxx/WEB-INF/src, where xxxx is the 
name of the webapp.  Please note that the exploded webapp IS NOT
ready to go as-is, it has to be compiled.

Thank you very much for purchasing and reading my book!  Take care!

Frank W. Zammetti
7/8/2006
