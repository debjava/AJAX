          /* This function returns the sum of two numbers */
function addTwoNumbers(first, second)
{ 
    return first + second;
                }

 // This function concatenates two string
  function concatenateStrings(stringOne, stringTwo) {
return stringOne + stringTwo; 
}

/* This function iterates and
    shows an alert during each iteration
*/
function getSomeMessage() {
var message = "";
    for(var x = 0; x < 5; x++) {
            message = message + "\nOn iteration: " + x;
                alert(message);
             for(var i = 0; i < 3; i++) {
         //Do something useful here      
                    }
}
}