/**
 * Copyright 2005 Darren L. Spurgeon
 * Copyright 2007 Jens Kapitza
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.helpers;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;

import org.apache.commons.beanutils.BeanUtils;

/**
 * Helper class to build valid XML, for the AjaxTreeTag, typically returned in a
 * response to the client.
 * 
 * @author Musachy Barroso
 * @author Jens Kapitza
 * @version $Revision: 1.4 $ $Date: 2007/06/20 20:52:58 $ $Author: jenskapitza $
 */
public final class AjaxTreeXmlBuilder extends BaseXmlBuilder<TreeItem> {

	/**
	 * Add item to XML.
	 * 
	 * @param name
	 *            The name of the item
	 * @param value
	 *            The value of the item
	 * @param collapsed
	 *            The node is collapsed
	 * @param url
	 *            The url for the node
	 * @return
	 */
	public AjaxTreeXmlBuilder addItem(String name, String value,
			boolean collapsed, String url) {
		return addItem(name, value, collapsed, url, false);
	}

	public AjaxTreeXmlBuilder addItem(String name, String value,
			boolean collapsed, String url, boolean asCData) {
		add(new TreeItem(name, value, collapsed, url, asCData));
		return this;
	}

	/**
	 * Add item to XML. Collapsed by default.
	 * 
	 * @param name
	 *            The name of the item
	 * @param value
	 *            The value of the item
	 * @param collapsed
	 *            The node is collapsed
	 * @param url
	 *            The url for the node
	 * @return
	 */
	public AjaxTreeXmlBuilder addItem(String name, String value, String url) {
		return addItem(name, value, true, url);
	}

	/**
	 * Add item wrapped with inside a CDATA element.
	 * 
	 * @param name
	 *            The name of the item
	 * @param value
	 *            The value of the item
	 * @param collapsed
	 *            The node is collapsed
	 * @param url
	 *            The url for the node
	 * @return
	 */
	public AjaxTreeXmlBuilder addItemAsCData(String name, String value,
			boolean collapsed, String url) {
		return addItem(name, value, collapsed, url, true);
	}

	/**
	 * Add items from a collection.
	 * 
	 * @param collection
	 * @param nameProperty
	 * @param collapsedProperty
	 * @param urlProperty
	 * @param valueProperty
	 * @return
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 */
	public AjaxTreeXmlBuilder addItems(Collection<?> collection,
			String nameProperty, String valueProperty,
			String collapsedProperty, String urlProperty)
			throws IllegalAccessException, InvocationTargetException,
			NoSuchMethodException {
		return addItems(collection, nameProperty, valueProperty,
				collapsedProperty, urlProperty, false);
	}

	/**
	 * Add items from a collection.
	 * 
	 * @param collection
	 * @param nameProperty
	 * @param valueProperty
	 * @return
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 */
	public AjaxTreeXmlBuilder addItems(Collection<?> collection,
			String nameProperty, String valueProperty,
			String collapsedProperty, String urlProperty, boolean asCData)
			throws IllegalAccessException, InvocationTargetException,
			NoSuchMethodException {
		for (Object element : collection) {
			String name = BeanUtils.getProperty(element, nameProperty);
			String value = BeanUtils.getProperty(element, valueProperty);
			boolean collapsed = Boolean.parseBoolean(BeanUtils.getProperty(
					element, collapsedProperty));
			String url = BeanUtils.getProperty(element, urlProperty);
			addItem(name, value, collapsed, url, asCData);
		}
		return this;
	}

	/**
	 * Add items from a collection as CDATA element.
	 * 
	 * @param collection
	 * @param nameProperty
	 * @param valueProperty
	 * @param collapsedProperty
	 * @param urlProperty
	 * @return
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 */
	public AjaxTreeXmlBuilder addItemsAsCData(Collection<?> collection,
			String nameProperty, String valueProperty,
			String collapsedProperty, String urlProperty)
			throws IllegalAccessException, InvocationTargetException,
			NoSuchMethodException {
		return addItems(collection, nameProperty, valueProperty,
				collapsedProperty, urlProperty, true);
	}

	/**
	 * build an xml body to describe TreeItem
	 * 
	 * @see BaseXmlBuilder.#getXMLString()
	 * 
	 */
	@Override
	protected String getXMLString() {
		StringBuffer xml = new StringBuffer();

		xml.append("<ajax-response>");
		xml.append("<response>");
		for (TreeItem item : getItems()) {
			xml.append("<item>");
			xml.append("<name>");
			if (item.isAsCData()) {
				xml.append("<![CDATA[");
			}
			xml.append(item.getName());
			if (item.isAsCData()) {
				xml.append("]]>");
			}
			xml.append("</name>");
			xml.append("<value>");
			if (item.isAsCData()) {
				xml.append("<![CDATA[");
			}
			xml.append(item.getValue());
			if (item.isAsCData()) {
				xml.append("]]>");
			}
			xml.append("</value>");

			xml.append("<collapsed>");
			xml.append(item.isCollapsed());
			xml.append("</collapsed>");

			xml.append("<url>");
			xml.append(item.getUrl());
			xml.append("</url>");

			xml.append("</item>");
		}
		xml.append("</response>");
		xml.append("</ajax-response>");

		return xml.toString();

	}

}
