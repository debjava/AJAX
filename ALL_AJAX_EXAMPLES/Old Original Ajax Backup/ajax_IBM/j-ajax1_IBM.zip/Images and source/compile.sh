javac -d ~/jetty/webapps/ajax/WEB-INF/classes/ -cp ~/jetty/lib/javax.servlet.jar src/developerworks/ajax/servlet/*.java src/developerworks/ajax/store/*.java
