package coreservlets.client;

import com.google.gwt.core.client.*;
import com.google.gwt.user.client.*;
import com.google.gwt.user.client.ui.*;
import com.google.gwt.user.client.rpc.*;

public class RPCApp implements EntryPoint {
  private HTML label1, label2, label3;
  private TextBox rangeBox;
  private DataServiceAsync dataService;
  
  public void onModuleLoad() {
    Button button1 = new Button("Show Random Number");
    label1 = new HTML("<i>Num will go here</i>");
    Button button2 = new Button("Show Random Numbers");
    label2 = new HTML("<i>List will go here</i>");
    Button button3 = new Button("Show Random Number");
    rangeBox = new TextBox();
    label3 = new HTML("<i>Num will go here</i>");
    
    button1.addClickListener(new Button1Listener());
    button2.addClickListener(new Button2Listener());
    button3.addClickListener(new Button3Listener());
    
    RootPanel.get("button1").add(button1);
    RootPanel.get("label1").add(label1);
    RootPanel.get("button2").add(button2);
    RootPanel.get("label2").add(label2);
    RootPanel.get("button3").add(button3);
    RootPanel.get("rangeBox").add(rangeBox);
    RootPanel.get("label3").add(label3);
    
    dataService = getDataService();
  }
  
  private class Button1Listener implements ClickListener {
    public void onClick(Widget sender) {
      dataService.getButton1Data(new Button1Callback());
    }
  }
  
  private class Button2Listener implements ClickListener {
    public void onClick(Widget sender) {
      dataService.getButton2Data(new Button2Callback());
    }
  }
  
  private class Button3Listener implements ClickListener {
    public void onClick(Widget sender) {
      String range = rangeBox.getText();
      dataService.getButton3Data(range, 
                                 new Button3Callback());
    }
  }
  
  private DataServiceAsync getDataService() {
    DataServiceAsync dataService = 
      (DataServiceAsync)GWT.create(DataService.class);
    ServiceDefTarget endpoint = (ServiceDefTarget)dataService;
    endpoint.setServiceEntryPoint("/coreservlets.RPCApp/DataService");
    return(dataService);
  }
  
  private class Button1Callback implements AsyncCallback {
    public void onSuccess(Object serverData) {
      String result = (String)serverData;
      label1.setHTML(result);
    }
      
    public void onFailure(Throwable caught) {
      Window.alert("Unable to get data from server.");
    }
  }
  
  private class Button2Callback implements AsyncCallback {
    public void onSuccess(Object serverData) {
      String[] listItems = (String[])serverData;
      String result = "<ul>\n";
      for(int i=0; i<listItems.length; i++) {
        result = result + "<li>" + listItems[i] + "</li>\n"; 
      }
      result = result + "</ul>";
      label2.setHTML(result);
    }
      
    public void onFailure(Throwable caught) {
      Window.alert("Unable to get data from server.");
    }
  }
  
  private class Button3Callback implements AsyncCallback {
    public void onSuccess(Object serverData) {
      RandomNumber number = (RandomNumber)serverData;
      String range = "Range: " + number.getRange();
      if (!number.isRangeLegal()) {
        range = range + " (default due to illegal range)";
      }
      String value = "Value: " + number.getValue();
      String result = "<ul>\n" +
                      "<li>" + range + "</li>\n" +
                      "<li>" + value + "</li>\n" +
                      "</ul>";
      label3.setHTML(result);
    } 
      
    public void onFailure(Throwable caught) {
      Window.alert("Unable to get data from server.");
    }
  }
}
