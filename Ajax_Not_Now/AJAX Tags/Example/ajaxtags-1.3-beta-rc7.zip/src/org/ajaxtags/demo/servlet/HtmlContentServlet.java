/**
 * Copyright 2005 Darren L. Spurgeon
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.demo.servlet;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.ajaxtags.demo.Car;
import org.ajaxtags.demo.CarService;
import org.ajaxtags.servlets.BaseAjaxServlet;

/**
 * An example servlet that responds to an ajax:htmlContent tag action.
 * 
 * @author Darren L. Spurgeon
 * @version $Revision: 1.2 $ $Date: 2007/06/08 23:59:02 $
 */
public class HtmlContentServlet extends BaseAjaxServlet {

  /**
   * @see org.ajaxtags.demo.servlet.BaseAjaxServlet#getXmlContent(javax.servlet.http.HttpServletRequest,
   *      javax.servlet.http.HttpServletResponse)
   */
  public String getXmlContent(HttpServletRequest request, HttpServletResponse response)
      throws Exception {
    String make = request.getParameter("make");
    CarService service = new CarService();
    List<Car> list = service.getModelsByMake(make);

    StringBuffer html = new StringBuffer();
    html.append("<h2>").append(make.toUpperCase()).append("</h2><p>Models</p><ul>");
    for (Iterator<Car> iter = list.iterator(); iter.hasNext();) {
      Car car =   iter.next();
      html.append("<li>").append(car.getModel()).append("</li>");
    }
    html.append("</ul>");
    html.append("<br>");
    html.append("<code>Last Updated: ");
    html.append(new Date());
    html.append("</code>");

    return html.toString();
  }

}
