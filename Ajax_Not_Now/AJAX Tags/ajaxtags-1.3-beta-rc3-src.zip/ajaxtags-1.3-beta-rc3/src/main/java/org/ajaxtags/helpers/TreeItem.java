/**
 * Copyright 2005 Darren L. Spurgeon
 * Copyright 2007 Jens Kapitza
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.helpers;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * 
 * @author Musachy Barroso
 * @author Jens Kapitza
 * @version $Revision: 1.2 $ $Date: 2007/06/20 20:55:57 $ $Author: jenskapitza $
 */
class TreeItem extends Item {

	private boolean collapsed;

	private String url;

	/**
	 * Constructor for TreeItem
	 */
	TreeItem() {
		super();
	}

	/**
	 * @param name
	 * @param value
	 * @param collapsed
	 * @param url
	 * @param asData
	 */
	TreeItem(String name, String value, boolean collapsed, String url,
			boolean asData) {
		super(name, value, asData);
		this.collapsed = collapsed;
		this.url = url;
	}

	/**
	 * @return Returns the colapsed value
	 */
	public boolean isCollapsed() {
		return this.collapsed;
	}

	/**
	 * @param The
	 *            collapsed value to be set
	 */
	public void setCollapsed(boolean collapsed) {
		this.collapsed = collapsed;
	}

	/**
	 * @return Return the URL
	 */
	public String getUrl() {
		return this.url;
	}

	/**
	 * @param The
	 *            url to be set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return new ToStringBuilder(this).append("name", this.name).append(
				"value", this.value).append("asData", this.asData).append(
				"collapsed", this.collapsed).append("url", this.url).toString();
	}
}
