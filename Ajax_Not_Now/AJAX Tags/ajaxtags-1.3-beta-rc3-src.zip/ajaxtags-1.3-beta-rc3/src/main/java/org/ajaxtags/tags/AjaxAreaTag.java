/**
 * Copyright 2005 Darren L. Spurgeon
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.tags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyTagSupport;

import org.ajaxtags.helpers.AjaxHtmlHelper;
import org.apache.commons.lang.StringUtils;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;

/**
 * Wraps any area on the page (with a DIV element) so that actions within that
 * area refresh/load inside the defined DIV region rather than inside the whole
 * browser window.
 * 
 * @author Darren Spurgeon
 * @version $Revision: 1.2 $ $Date: 2007/06/20 20:55:56 $ $Author: jenskapitza $
 */
public class AjaxAreaTag extends BodyTagSupport {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7940387487602588115L;

	private String ajaxFlag = "ajax";

	private String style;

	private String styleClass;

	private String ajaxAnchors = "false";

	private boolean ajax = false;

	/**
	 * @return Returns the ajaxFlag.
	 */
	public String getAjaxFlag() {
		return this.ajaxFlag;
	}

	/**
	 * @param ajaxFlag
	 *            The ajaxFlag to set.
	 */
	public void setAjaxFlag(String ajaxFlag) {
		this.ajaxFlag = ajaxFlag;
	}

	/**
	 * @return Returns the style.
	 */
	public String getStyle() {
		return this.style;
	}

	/**
	 * @param style
	 *            The style to set.
	 */
	public void setStyle(String style) {
		this.style = style;
	}

	/**
	 * @return Returns the styleClass.
	 */
	public String getStyleClass() {
		return this.styleClass;
	}

	/**
	 * @param styleClass
	 *            The styleClass to set.
	 */
	public void setStyleClass(String styleClass) {
		this.styleClass = styleClass;
	}

	/**
	 * @return Returns the ajaxAnchors.
	 */
	public String getAjaxAnchors() {
		return this.ajaxAnchors;
	}

	/**
	 * @param ajaxAnchors
	 *            The ajaxAnchors to set.
	 */
	public void setAjaxAnchors(String ajaxAnchors) {
		this.ajaxAnchors = ajaxAnchors;
	}

	/**
	 * @see javax.servlet.jsp.tagext.Tag#doStartTag()
	 */
	@Override
	public int doStartTag() throws JspException {

		initParameters();

		if (this.ajax) {
			try {
				pageContext.getOut().clearBuffer();
				// pageContext.getOut().clear();
				// pageContext.getOut().flush();
			} catch (IOException ex) {
				throw new JspException(ex.getMessage());
			}
		} else {
			JspWriter out = pageContext.getOut();
			try {
				out.print("<div");
				if (StringUtils.isNotBlank(id)) {
					out.print(" id='" + this.id + "'");
				}
				if (StringUtils.isNotBlank(styleClass)) {
					out.print(" class='" + this.styleClass + "'");
				}
				if (StringUtils.isNotBlank(style)) {
					out.print(" style='" + this.style + "'");
				}
				out.print(">");
			} catch (IOException ex) {
				throw new JspException(ex.getMessage());
			}
		}
		return EVAL_BODY_BUFFERED;
	}

	/**
	 * @see javax.servlet.jsp.tagext.Tag#doEndTag()
	 */
	@Override
	public int doEndTag() throws JspException {
		JspWriter out = pageContext.getOut();
		String body = bodyContent.getString();
		try {
			body = processContent(body);
			out.println(body);
			if (!this.ajax) {
				out.println("</div>");
			}
		} catch (IOException ex) {
			throw new JspException(ex.getMessage());
		}
		return this.ajax ? SKIP_PAGE : EVAL_PAGE;
	}

	/**
	 * @see javax.servlet.jsp.tagext.Tag#release()
	 */
	@Override
	public void release() {
		this.ajaxFlag = null;
		this.style = null;
		this.ajaxAnchors = null;
		this.styleClass = null;
		super.release();
	}

	/**
	 * Set initial parameters.
	 * 
	 * @throws JspException
	 */
	protected void initParameters() throws JspException {
		// Optional Properties
		if (this.ajaxFlag != null) {
			this.ajaxFlag = (String) ExpressionEvaluatorManager.evaluate(
					"ajaxFlag", this.ajaxFlag, String.class, this,
					super.pageContext);
		}
		if (this.style != null) {
			this.style = (String) ExpressionEvaluatorManager.evaluate("style",
					this.style, String.class, this, super.pageContext);
		}
		if (this.styleClass != null) {
			this.styleClass = (String) ExpressionEvaluatorManager.evaluate(
					"styleClass", this.styleClass, String.class, this,
					super.pageContext);
		}
		if (this.ajaxAnchors != null) {
			this.ajaxAnchors = (String) ExpressionEvaluatorManager.evaluate(
					"ajaxAnchors", this.ajaxAnchors, String.class, this,
					super.pageContext);
		}

		this.ajax = Boolean.valueOf(
				pageContext.getRequest().getParameter(this.ajaxFlag))
				.booleanValue();
	}

	/**
	 * Process content.
	 * 
	 * @param content
	 * @return
	 */
	protected String processContent(String content) {
		return Boolean.valueOf(ajaxAnchors).booleanValue() ? AjaxHtmlHelper
				.ajaxAnchors(content, this.id, this.ajaxFlag) : content;
	}

}
