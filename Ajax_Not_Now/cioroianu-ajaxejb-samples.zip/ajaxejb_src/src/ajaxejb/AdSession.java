package ajaxejb;

import java.util.List;

import javax.ejb.Remote;

@Remote
public interface AdSession {
    Object mergeEntity(Object entity);

    Object persistEntity(Object entity);

    List<AdEntity> queryAdEntityFindAll();

    void removeAdEntity(AdEntity adEntity);

    AdEntity selectAd(String userInput);
}
