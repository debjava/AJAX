/**
 * Copyright 2005 Darren L. Spurgeon
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.tags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;

/**
 * Wraps the scriptaculous' in-place editor
 * (http://wiki.script.aculo.us/scriptaculous/show/Ajax.InPlaceEditor)
 * 
 * @author Musachy Barroso
 * @version $Revision: 1.2 $ $Date: 2007/06/20 20:55:56 $ $Author: jenskapitza $
 */
public class AjaxEditorTag extends TagSupport {
	private boolean showAcceptButton;

	private String acceptText;

	private boolean showCancelLink;

	private String cancelText;

	private String savingText;

	private String mouseOverText;

	private String styleId;

	private String rows;

	private String columns;

	private String postFunction;

	private String errorFunction;

	private String preFunction;

	private String highlightColor;

	private String target;

	private String baseUrl;

	@Override
	public int doStartTag() throws JspException {
		// Required Properties
		this.baseUrl = (String) ExpressionEvaluatorManager.evaluate("baseUrl",
				this.baseUrl, String.class, this, super.pageContext);
		this.target = (String) ExpressionEvaluatorManager.evaluate("target",
				this.target, String.class, this, super.pageContext);

		// Optional Properties
		if (showAcceptButton && this.acceptText != null) {
			this.acceptText = (String) ExpressionEvaluatorManager.evaluate(
					"acceptText", this.acceptText, String.class, this,
					super.pageContext);
		}
		if (showCancelLink && this.cancelText != null) {
			this.cancelText = (String) ExpressionEvaluatorManager.evaluate(
					"cancelText", this.cancelText, String.class, this,
					super.pageContext);
		}
		if (this.savingText != null) {
			this.savingText = (String) ExpressionEvaluatorManager.evaluate(
					"savingText", this.savingText, String.class, this,
					super.pageContext);
		}
		if (this.mouseOverText != null) {
			this.mouseOverText = (String) ExpressionEvaluatorManager.evaluate(
					"mouseOverText", this.mouseOverText, String.class, this,
					super.pageContext);
		}
		if (this.styleId != null) {
			this.styleId = (String) ExpressionEvaluatorManager.evaluate(
					"styleId", this.styleId, String.class, this,
					super.pageContext);
		}
		if (this.rows != null) {
			this.rows = (String) ExpressionEvaluatorManager.evaluate("rows",
					this.rows, String.class, this, super.pageContext);
		}
		if (this.columns != null) {
			this.columns = (String) ExpressionEvaluatorManager.evaluate(
					"columns", this.columns, String.class, this,
					super.pageContext);
		}
		if (this.postFunction != null) {
			this.postFunction = (String) ExpressionEvaluatorManager.evaluate(
					"postFunction", this.postFunction, String.class, this,
					super.pageContext);
		}
		if (this.errorFunction != null) {
			this.errorFunction = (String) ExpressionEvaluatorManager.evaluate(
					"errorFunction", this.errorFunction, String.class, this,
					super.pageContext);
		}
		if (this.preFunction != null) {
			this.preFunction = (String) ExpressionEvaluatorManager.evaluate(
					"preFunction", this.preFunction, String.class, this,
					super.pageContext);
		}
		if (this.highlightColor != null) {
			this.highlightColor = (String) ExpressionEvaluatorManager.evaluate(
					"highlightColor", this.highlightColor, String.class, this,
					super.pageContext);
		}

		return SKIP_BODY;
	}

	@Override
	public int doEndTag() throws JspException {
		OptionsBuilder options = new OptionsBuilder();

		options.add("okButton", this.showAcceptButton ? "true" : "false", true);
		if (this.showAcceptButton && this.acceptText != null)
			options.add("okText", this.acceptText, true);

		options.add("cancelLink", this.showCancelLink ? "true" : "false", true);
		if (this.showCancelLink && this.cancelText != null)
			options.add("cancelText", this.cancelText, true);

		if (this.savingText != null)
			options.add("savingText", this.savingText, true);
		if (this.mouseOverText != null)
			options.add("clickToEditText", this.mouseOverText, true);
		if (this.preFunction != null)
			options.add("callback", this.preFunction, false);
		if (this.postFunction != null)
			options.add("onComplete", this.postFunction, false);
		if (this.errorFunction != null)
			options.add("onFailure", this.errorFunction, false);
		if (this.styleId != null)
			options.add("formId", this.styleId, true);
		if (this.rows != null)
			options.add("rows", this.rows, true);
		if (this.columns != null)
			options.add("cols", this.columns, true);
		if (this.highlightColor != null)
			options.add("highlightColor", this.highlightColor, true);

		StringBuffer script = new StringBuffer();
		script.append("<script type=\"text/javascript\">\n");
		script.append("var editor_").append(target);
		script.append(" = new Ajax.InPlaceEditor(\"");
		script.append(target);
		script.append("\", \"");
		script.append(this.baseUrl);
		script.append("\", {\n");
		script.append(options.toString());
		script.append("});\n");
		script.append("</script>\n\n");

		JspWriter writer = pageContext.getOut();
		try {
			writer.println(script);
		} catch (IOException e) {
			throw new JspException(e.getMessage());
		}
		return EVAL_PAGE;
	}

	public String getAcceptText() {
		return acceptText;
	}

	public void setAcceptText(String acceptText) {
		this.acceptText = acceptText;
	}

	public String getCancelText() {
		return cancelText;
	}

	public void setCancelText(String cancelText) {
		this.cancelText = cancelText;
	}

	public String getColumns() {
		return columns;
	}

	public void setColumns(String columns) {
		this.columns = columns;
	}

	public String getErrorFunction() {
		return errorFunction;
	}

	public void setErrorFunction(String errorFunction) {
		this.errorFunction = errorFunction;
	}

	public String getHighlightColor() {
		return highlightColor;
	}

	public void setHighlightColor(String highlightColor) {
		this.highlightColor = highlightColor;
	}

	public String getMouseOverText() {
		return mouseOverText;
	}

	public void setMouseOverText(String mouseOverText) {
		this.mouseOverText = mouseOverText;
	}

	public String getPostFunction() {
		return postFunction;
	}

	public void setPostFunction(String postFunction) {
		this.postFunction = postFunction;
	}

	public String getPreFunction() {
		return preFunction;
	}

	public void setPreFunction(String prerFunction) {
		this.preFunction = prerFunction;
	}

	public String getRows() {
		return rows;
	}

	public void setRows(String rows) {
		this.rows = rows;
	}

	public String getSavingText() {
		return savingText;
	}

	public void setSavingText(String savingText) {
		this.savingText = savingText;
	}

	public boolean isShowAcceptButton() {
		return showAcceptButton;
	}

	public void setShowAcceptButton(boolean showAcceptButton) {
		this.showAcceptButton = showAcceptButton;
	}

	public boolean isShowCancelLink() {
		return showCancelLink;
	}

	public void setShowCancelLink(boolean showCancelLink) {
		this.showCancelLink = showCancelLink;
	}

	public String getStyleId() {
		return styleId;
	}

	public void setStyleId(String styleId) {
		this.styleId = styleId;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseURL) {
		this.baseUrl = baseURL;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}
}
