/**
 * Copyright 2005 Darren L. Spurgeon
 * Copyright 2007 Jens Kapitza
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.helpers;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.ajaxtags.tags.OptionsBuilder;
import org.apache.commons.lang.StringUtils;

import au.id.jericho.lib.html.Attribute;
import au.id.jericho.lib.html.Attributes;
import au.id.jericho.lib.html.Element;
import au.id.jericho.lib.html.HTMLElementName;
import au.id.jericho.lib.html.OutputDocument;
import au.id.jericho.lib.html.Source;
import au.id.jericho.lib.html.StartTag;

/**
 * A helper class to assist in AJAX-enabling certain HTML elements/attributes
 * used by other tags.
 * @author Darren L. Spurgeon
 * @author Jens Kapitza
 * @version $Revision: 1.2 $ $Date: 2007/06/20 20:52:58 $ $Author: jenskapitza $
 */
public class AjaxHtmlHelper {

	/**
	 * Get the content of an HTML tag based on tag name.
	 * 
	 * @param html
	 * @param tag
	 * @return
	 */
	public static String getTagContent(final String html, final String tag) {
		// if (StringUtils.isBlank(html))
		// return null;
		// Source source = new Source(html);
		// return source.findNextStartTag(1, tag).getElement().getContent()
		// .toString();
		return getTagContent(html, tag, null);
	}

	/**
	 * Get the content of an HTML tag based on tag and class names.
	 * 
	 * @param html
	 * @param tag
	 * @param className
	 * @return
	 */
	public static String getTagContent(final String html, final String tag,
			final String className) {
		if (StringUtils.isBlank(html))
			return null;

		Source source = new Source(html);
		// Rewrite pagination links
		List<?> spans = source.findAllElements(tag);
		for (Iterator<?> spanIter = spans.iterator(); spanIter.hasNext();) {
			Element spanElement = (Element) spanIter.next();
			// If no class is especified return firt tag
			if (StringUtils.isBlank(className)) {
				return spanElement.getContent().toString();
			}
			Attributes spanAttributes = spanElement.getAttributes();
			Attribute classAttribute = spanAttributes.get("class");
			if (classAttribute != null && classAttribute.getValue() != null
					&& classAttribute.getValue().equalsIgnoreCase(className)) {
				return spanElement.getContent().toString();
			}
		}
		return null;
	}

	/**
	 * Get the content of an HTML tag based on its id.
	 * 
	 * @param html
	 * @param id
	 * @return
	 */
	public static String getTagContentById(final String html, final String id) {
		if (StringUtils.isBlank(html))
			return null;

		Source source = new Source(html);
		List<?> spans = source.findAllElements();
		for (Iterator<?> spanIter = spans.iterator(); spanIter.hasNext();) {
			Element spanElement = (Element) spanIter.next();
			Attributes spanAttributes = spanElement.getAttributes();
			Attribute classAttribute = spanAttributes.get("id");
			if (classAttribute != null && classAttribute.getValue() != null
					&& classAttribute.getValue().equalsIgnoreCase(id)) {
				return spanElement.getContent().toString();
			}
		}

		return null;

	}

	/**
	 * AJAX-enable HTML anchor tags.
	 * 
	 * @param html
	 * @param target
	 * @return
	 */
	public static String ajaxAnchors(final String html, final String target) {
		return ajaxAnchors(html, target, null);
	}

	/**
	 * AJAX-enable HTML anchor tags.
	 * 
	 * @param html
	 * @param target
	 * @param ajaxFlag
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static String ajaxAnchors(final String html, final String target,
			String ajaxFlag) {
		if (StringUtils.isBlank(html))
			return null;

		Source source = new Source(html);
		OutputDocument outputDocument = new OutputDocument(source);

		List<?> anchors = source.findAllStartTags(HTMLElementName.A);
		for (Iterator<?> i = anchors.iterator(); i.hasNext();) {
			StartTag anchorTag = (StartTag) i.next();
			Attributes attributes = anchorTag.getAttributes();
			Attribute hrefAttribute = attributes.get("href");
			if (hrefAttribute == null)
				continue;
			String href = hrefAttribute.getValue();
			if (href == null)
				continue;
			OptionsBuilder options = new OptionsBuilder();
			options.add("evalScripts", "true", false);
			Map<String, String> attrreplace = outputDocument.replace(
					attributes, true);

			attrreplace.put("href", "javascript://nop/");
			attrreplace.put("onclick", getOnclickAjax(target, href, ajaxFlag,
					options));

			// outputDocument.replace(attributes, attrreplace);
			//  
			// AttributesOutputSegment outputSegment = new
			// AttributesOutputSegment(attributes, true);
			// outputSegment.getMap().put("href", "javascript://nop/");
			// outputSegment.getMap().put("onclick", getOnclickAjax(target,
			// href, ajaxFlag, options));
			// outputDocument.add(outputSegment);
		}
		return outputDocument.toString();
	}

	/**
	 * Helper to define new AJAX updater for onclick attribute.
	 * 
	 * @param target
	 * @param href
	 * @param ajaxFlag
	 * @return
	 */
	public static final String getOnclickAjax(String target, String href,
			String ajaxFlag) {
		return getOnclickAjax(target, href, ajaxFlag, null);
	}

	/**
	 * Helper to define new AJAX updater for onclick attribute.
	 * 
	 * @param target
	 * @param href
	 * @param ajaxFlag
	 * @param options
	 * @return
	 */
	public static final String getOnclickAjax(String target, String href,
			String ajaxFlag, OptionsBuilder options) {
		StringBuffer onclick = new StringBuffer("new Ajax.Updater('");
		onclick.append(target);
		onclick.append("', '");
		onclick.append(href);
		if (StringUtils.isNotBlank(ajaxFlag)) {
			if (href.indexOf(ajaxFlag + "=") < 0) {
				if (href.indexOf("?") >= 0) {
					onclick.append("&");
				} else {
					onclick.append("?");
				}
				onclick.append(ajaxFlag);
				onclick.append("=true");
			}
		}
		onclick.append("'");
		if (options != null) {
			onclick.append(",{");
			onclick.append(options.toString());
			onclick.append("}");
		}
		onclick.append("); return false;");

		return onclick.toString();
	}

}
