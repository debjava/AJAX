/**
 * Copyright 2005 Darren L. Spurgeon
 * Copyright 2007 Jens Kapitza
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.tags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.commons.lang.StringUtils;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;

/**
 * Tag handler for the form field AJAX tag.
 * 
 * @author Darren Spurgeon
 * @author Jens Kapitza
 * @version $Revision: 1.2 $ $Date: 2007/06/20 20:55:56 $ $Author: jenskapitza $
 */
public class AjaxFormFieldTag extends TagSupport {

	private String var;

	private String attachTo;

	private String source;

	private String target;

	private String action;

	private String baseUrl;

	private String parameters;

	private String eventType;

	private String preFunction;

	private String postFunction;

	private String errorFunction;

	private String parser;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getErrorFunction() {
		return errorFunction;
	}

	public void setErrorFunction(String errorFunction) {
		this.errorFunction = errorFunction;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getVar() {
		return var;
	}

	public void setVar(String var) {
		this.var = var;
	}

	public String getAttachTo() {
		return attachTo;
	}

	public void setAttachTo(String attachTo) {
		this.attachTo = attachTo;
	}

	public String getParameters() {
		return parameters;
	}

	public void setParameters(String parameters) {
		this.parameters = parameters;
	}

	public String getParser() {
		return parser;
	}

	public void setParser(String parser) {
		this.parser = parser;
	}

	public String getPreFunction() {
		return preFunction;
	}

	public void setPreFunction(String preFunction) {
		this.preFunction = preFunction;
	}

	public String getPostFunction() {
		return postFunction;
	}

	public void setPostFunction(String postFunction) {
		this.postFunction = postFunction;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	private boolean valueUpdateByName;
	
	
	private boolean doPost;

	public void setDoPost(boolean doPost) {
		this.doPost = doPost;
	}

	public boolean getDoPost() {
		return this.doPost;
	}

	@Override
	public int doStartTag() throws JspException {
		// Required Properties
		this.baseUrl = (String) ExpressionEvaluatorManager.evaluate("baseUrl",
				this.baseUrl, String.class, this, super.pageContext);
		this.source = (String) ExpressionEvaluatorManager.evaluate("source",
				this.source, String.class, this, super.pageContext);
		this.target = (String) ExpressionEvaluatorManager.evaluate("target",
				this.target, String.class, this, super.pageContext);
		this.action = (String) ExpressionEvaluatorManager.evaluate("action",
				this.action, String.class, this, super.pageContext);
		this.parameters = (String) ExpressionEvaluatorManager.evaluate(
				"parameters", this.parameters, String.class, this,
				super.pageContext);

		// Optional Properties
		if (this.var != null) {
			this.var = (String) ExpressionEvaluatorManager.evaluate("var",
					this.var, String.class, this, super.pageContext);
		}
		if (this.attachTo != null) {
			this.attachTo = (String) ExpressionEvaluatorManager.evaluate(
					"attachTo", this.attachTo, String.class, this,
					super.pageContext);
		}
		if (this.eventType != null) {
			this.eventType = (String) ExpressionEvaluatorManager.evaluate(
					"eventType", this.eventType, String.class, this,
					super.pageContext);
		}
		if (this.preFunction != null) {
			this.preFunction = (String) ExpressionEvaluatorManager.evaluate(
					"preFunction", this.preFunction, String.class, this,
					super.pageContext);
		}
		if (this.postFunction != null) {
			this.postFunction = (String) ExpressionEvaluatorManager.evaluate(
					"postFunction", this.postFunction, String.class, this,
					super.pageContext);
		}
		if (this.errorFunction != null) {
			this.errorFunction = (String) ExpressionEvaluatorManager.evaluate(
					"errorFunction", this.errorFunction, String.class, this,
					super.pageContext);
		}
		return SKIP_BODY;
	}

	@Override
	public int doEndTag() throws JspException {
		OptionsBuilder options = new OptionsBuilder();
		options.add("source", this.source, true).add("target", this.target,
				true).add("action", this.action, true).add("parameters",
				this.parameters, true);
		if (this.eventType != null)
			options.add("eventType", this.eventType, true);
		if (this.preFunction != null)
			options.add("preFunction", this.preFunction, false);
		if (this.postFunction != null)
			options.add("postFunction", this.postFunction, false);
		if (this.errorFunction != null)
			options.add("errorFunction", this.errorFunction, false);
		if (this.parser != null)
			options.add("parser", this.parser, false);
		if (this.doPost)
			options.add("doPost", String.valueOf(this.doPost), false);
		if (this.valueUpdateByName)
			options.add("valueUpdateByName", String.valueOf(this.valueUpdateByName), false);

		StringBuffer script = new StringBuffer();
		script.append("<script type=\"text/javascript\">\n");

		if (StringUtils.isNotEmpty(this.attachTo)) {
			script.append(this.attachTo).append(".");
			if (StringUtils.isNotEmpty(this.var)) {
				script.append(this.var);
			} else {
				script.append("aj_").append(this.source);
			}
		} else if (StringUtils.isNotEmpty(this.var)) {
			script.append("var ").append(this.var);
		} else {
			script.append("var aj_").append(this.source);
		}

		script.append(" = new AjaxJspTag.UpdateField(\n").append("\"").append(
				this.baseUrl).append("\", {\n").append(options.toString())
				.append("});\n").append("</script>\n\n");

		JspWriter writer = pageContext.getOut();
		try {
			writer.println(script);
		} catch (IOException e) {
			throw new JspException(e.getMessage());
		}
		return EVAL_PAGE;
	}

	@Override
	public void release() {
		this.var = null;
		this.valueUpdateByName = false;
		this.attachTo = null;
		this.baseUrl = null;
		this.source = null;
		this.target = null;
		this.action = null;
		this.parameters = null;
		this.eventType = null;
		this.preFunction = null;
		this.postFunction = null;
		this.errorFunction = null;
		this.parser = null;
		super.release();
	}

	public boolean getValueUpdateByName() {
		return valueUpdateByName;
	}

	public void setValueUpdateByName(boolean valueUpdateByName) {
		this.valueUpdateByName = valueUpdateByName;
	}

}
