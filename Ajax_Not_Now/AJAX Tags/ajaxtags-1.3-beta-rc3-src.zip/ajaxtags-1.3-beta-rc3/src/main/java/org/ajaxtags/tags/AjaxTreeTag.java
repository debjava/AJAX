/**
 * Copyright 2005 Darren L. Spurgeon
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.tags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;

/**
 * Tag handler for the tree AJAX tag.
 * 
 * @author Musachy Barroso
 * @version $Revision: 1.2 $ $Date: 2007/06/20 20:55:56 $ $Author: jenskapitza $
 */
public class AjaxTreeTag extends TagSupport {
	private String baseUrl;

	private String styleId;

	private String preFunction;

	private String postFunction;

	private String errorFunction;

	private String parser;

	private String collapsedClass;

	private String expandedClass;

	private String parameters;

	private String nodeClass;

	private String treeClass;

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getTreeClass() {
		return treeClass;
	}

	public void setTreeClass(String treeClass) {
		this.treeClass = treeClass;
	}

	public String getNodeClass() {
		return nodeClass;
	}

	public void setNodeClass(String nodeClass) {
		this.nodeClass = nodeClass;
	}

	public String getParameters() {
		return parameters;
	}

	public void setParameters(String parameters) {
		this.parameters = parameters;
	}

	@Override
	public int doStartTag() throws JspException {
		// Required Properties
		this.baseUrl = (String) ExpressionEvaluatorManager.evaluate("baseUrl",
				this.baseUrl, String.class, this, super.pageContext);
		this.parameters = (String) ExpressionEvaluatorManager.evaluate(
				"parameters", this.parameters, String.class, this,
				super.pageContext);

		// Optional properties
		if (this.collapsedClass != null)
			this.collapsedClass = (String) ExpressionEvaluatorManager.evaluate(
					"collapsedClass", this.collapsedClass, String.class, this,
					super.pageContext);
		if (this.nodeClass != null)
			this.nodeClass = (String) ExpressionEvaluatorManager.evaluate(
					"nodeClass", this.nodeClass, String.class, this,
					super.pageContext);
		if (this.expandedClass != null)
			this.expandedClass = (String) ExpressionEvaluatorManager.evaluate(
					"expandedClass", this.expandedClass, String.class, this,
					super.pageContext);
		if (this.treeClass != null)
			this.treeClass = (String) ExpressionEvaluatorManager.evaluate(
					"treeClass", this.treeClass, String.class, this,
					super.pageContext);
		return SKIP_BODY;
	}

	public String getStyleId() {
		return styleId;
	}

	public void setStyleId(String treeStyleId) {
		this.styleId = treeStyleId;
	}

	public String getErrorFunction() {
		return errorFunction;
	}

	public void setErrorFunction(String errorFunction) {
		this.errorFunction = errorFunction;
	}

	public String getParser() {
		return parser;
	}

	public void setParser(String parser) {
		this.parser = parser;
	}

	public String getPostFunction() {
		return postFunction;
	}

	public void setPostFunction(String postFunction) {
		this.postFunction = postFunction;
	}

	public String getPreFunction() {
		return preFunction;
	}

	public void setPreFunction(String preFunction) {
		this.preFunction = preFunction;
	}

	public String getCollapsedClass() {
		return collapsedClass;
	}

	public void setCollapsedClass(String collapsedClass) {
		this.collapsedClass = collapsedClass;
	}

	public String getExpandedClass() {
		return expandedClass;
	}

	public void setExpandedClass(String expandedClass) {
		this.expandedClass = expandedClass;
	}

	@Override
	public int doEndTag() throws JspException {
		OptionsBuilder options = new OptionsBuilder();
		options.add("target", "elem", false);

		if (this.collapsedClass != null)
			options.add("collapsedClass", this.collapsedClass, true);
		if (this.parameters != null)
			options.add("parameters", this.parameters, true);
		if (this.expandedClass != null)
			options.add("expandedClass", this.expandedClass, true);
		if (this.treeClass != null)
			options.add("treeClass", this.treeClass, true);
		if (this.nodeClass != null)
			options.add("nodeClass", this.nodeClass, true);
		if (this.preFunction != null)
			options.add("preFunction", this.preFunction, false);
		if (this.postFunction != null)
			options.add("postFunction", this.postFunction, false);
		if (this.errorFunction != null)
			options.add("errorFunction", this.errorFunction, false);
		if (this.parser != null)
			options.add("parser", this.parser, false);

		StringBuffer script = new StringBuffer();
		script.append("<div id=\"");
		script.append(this.styleId);
		script.append("\"></div>\n");
		script.append("<script type=\"text/javascript\">\n");
		script
				.append("window.toggleTreeNode = function(elem, url, params) {\n");

		script.append("var aj_").append(this.styleId);

		script.append(" = new AjaxJspTag.Tree(url, {\n").append(
				options.toString()).append("});\n").append("}\n\n").append(
				"addOnLoadEvent(function() {window.toggleTreeNode('").append(
				styleId).append("', '").append(this.baseUrl).append("', null")
				.append(");});\n").append("</script>\n\n");
		JspWriter writer = pageContext.getOut();
		try {
			writer.println(script);
		} catch (IOException e) {
			throw new JspException(e.getMessage());
		}
		return EVAL_PAGE;
	}

	@Override
	public void release() {
		baseUrl = null;
		styleId = null;
		preFunction = null;
		postFunction = null;
		errorFunction = null;
		parser = null;
		collapsedClass = null;
		expandedClass = null;
		parameters = null;
		nodeClass = null;
		treeClass = null;
		super.release();
	}
}
