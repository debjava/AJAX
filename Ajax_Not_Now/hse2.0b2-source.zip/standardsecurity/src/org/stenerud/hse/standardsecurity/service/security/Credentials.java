package org.stenerud.hse.standardsecurity.service.security;

/**
 * Credentials for logging into the system.
 * 
 * @author Karl Stenerud
 */
public interface Credentials
{
	//
}
