The PNG files are exports from classDiagram.zuml.
