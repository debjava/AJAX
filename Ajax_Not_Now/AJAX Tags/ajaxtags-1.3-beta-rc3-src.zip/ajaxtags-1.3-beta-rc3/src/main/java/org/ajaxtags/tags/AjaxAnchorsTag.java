/**
 * Copyright 2005 Darren L. Spurgeon
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.tags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyTagSupport;

import org.ajaxtags.helpers.AjaxHtmlHelper;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;

/**
 * Rewrites HTML anchor tags (<A>), replacing the href attribute with an
 * onclick event so that retrieved content is loaded inside a region on the
 * page.
 * 
 * @author Darren Spurgeon
 * @version $Revision: 1.2 $ $Date: 2007/06/20 20:55:56 $ $Author: jenskapitza $
 */
public class AjaxAnchorsTag extends BodyTagSupport {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1732745741282114289L;
	private String ajaxFlag = "ajax";
	private String target;

	/**
	 * @return Returns the ajaxFlag.
	 */
	public String getAjaxFlag() {
		return this.ajaxFlag;
	}

	/**
	 * @param ajaxFlag
	 *            The ajaxFlag to set.
	 */
	public void setAjaxFlag(String ajaxFlag) {
		this.ajaxFlag = ajaxFlag;
	}

	/**
	 * @return Returns the target.
	 */
	public String getTarget() {
		return this.target;
	}

	/**
	 * @param target
	 *            The target to set.
	 */
	public void setTarget(String target) {
		this.target = target;
	}

	/**
	 * @see javax.servlet.jsp.tagext.Tag#doStartTag()
	 */
	@Override
	public int doStartTag() throws JspException {
		initParameters();
		return EVAL_BODY_BUFFERED;
	}

	/**
	 * @see javax.servlet.jsp.tagext.Tag#doEndTag()
	 */
	@Override
	public int doEndTag() throws JspException {
		JspWriter out = pageContext.getOut();
		String body = bodyContent.getString();
		try {
			body = AjaxHtmlHelper.ajaxAnchors(body, this.target, this.ajaxFlag);
			out.println(body);
		} catch (IOException ex) {
			throw new JspException(ex.getMessage());
		}
		return EVAL_PAGE;
	}

	/**
	 * @see javax.servlet.jsp.tagext.Tag#release()
	 */
	@Override
	public void release() {
		this.ajaxFlag = null;
		this.target = null;
		super.release();
	}

	/**
	 * Set initial parameters.
	 * 
	 * @throws JspException
	 */
	protected void initParameters() throws JspException {
		// Optional Properties
		if (this.ajaxFlag != null) {
			this.ajaxFlag = (String) ExpressionEvaluatorManager.evaluate(
					"ajaxFlag", this.ajaxFlag, String.class, this,
					super.pageContext);
		}
		if (this.target != null) {
			this.target = (String) ExpressionEvaluatorManager.evaluate(
					"target", this.target, String.class, this,
					super.pageContext);
		}
	}

}
