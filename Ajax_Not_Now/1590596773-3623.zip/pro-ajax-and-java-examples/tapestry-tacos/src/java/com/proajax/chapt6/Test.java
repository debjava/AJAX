/*
 * Test.java
 *
 * Created on March 12, 2006, 3:55 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.proajax.chapt6;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.html.BasePage;

/**
 *
 * @author nate
 */
public abstract class Test extends BasePage {
  
  /**
   * Invoked by forms listener:userLogin specification.
   */
  
  public void doFoo(IRequestCycle cycle) {
  }    
}
