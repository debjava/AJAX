<?php
/*
============================================================
Project: End-to-End-Ajax application development

Purpose: This is an example scenario to be used in
 an IBM developerWorks article.

Last modified: May/17/2007.

This PHP module provides the logic to access a remote
Web service hosted on the Internet. This Web service
will return the complete and current stock details about a 
given stock ticker symbol.

This module shows how easy it is to consume a remote
Web Service (running on a .NET platform) using PHP
dynamically by pointing to a remote WSDL file for that
Web service.

It uses PHP SOAP Client library to accomplish that. 
============================================================
*/
   // Get the required Bank Logic PHP module.
   require_once("BankLogic.php");
   
   /*
   ============================================================
   Function: getStockPortfolioValue

   Last modified: May/17/2007.
   
   This function accepts an account holder name as input.
   In this scenario, all the account holders have a single stock
   in their respective portfolio. The code here obtains the 
   ticker symbol of the stock held by the given account holder.
   Then it uses PHP SOAP client to remotely invoke the 
   .NET based stock quote Web service and obtains the 
   XML-based response returned by that service. It parses the
   XML-based stock details response and gets the current 
   stock price of that stock. It then, calls another function
   inside of the Bank Logic PHP module to update the database
   with the new portfolio value.
   ============================================================ 
   */   
   function getStockPortfolioValue($accountHolderName) {
      // From the Bank Logic module, obtain all the account
      // information stored in the database.
      // [If someone wants to optimize it, a new function
      // could be written directly to return the account 
      // information for the given account holder, instead of
      // retrieving all the account information.]
      $finalResult = getAllAccountInformation();
      
      // Ensure that all the account information was read from the DB.
      if ($finalResult["ResultCode"] != 0) {
         // Some error occurred. Return now.
         return($finalResult);
      } // End of if ($finalResult["ResultCode"] != 0)
      
      // Get the account info of the customer who we are dealing with now.
      $accountInfoArray = $finalResult["AccountInfo"];
      $tickerSymbol = null;
      
      // Loop through all the available account information and filter
      // the account information for the account holder's name that was
      // passed as a parameter to the function we are in now.
      foreach ($accountInfoArray as $accountInfo) {
         // Is it the account for the person of interest? 
         if (strcasecmp($accountInfo["AccountHolderName"], $accountHolderName) == 0) {
            // Get the stock ticker symbol of the only stock held in this portfolio.
            $tickerSymbol = $accountInfo["StockName"];
            // We got it. Skip out of the loop now.
            break;
         } // End of if (strcasecmp($accountInfo["AccountHolderName"] ...
      } // End of foreach ($accountInfoArray as $accountInfo)
      
      // If there was an error in getting the ticker symbol, return now.
      if ($tickerSymbol == null) {
         $finalResult["ResultCode"] = 1;
         $finalResult["ResultMsg"] = 
            "Unable to get ticker symbol from the account of $accountHolderName.";
         return($finalResult);                  
      } // End of if ($tickerSymbol == null)
      
      // This is the WSDL published by the service provider.
      $wsdl = "http://www.webservicex.net/stockquote.asmx?WSDL"; 
      // The magic happens here in the next four lines to execute
      // a fairly complex function remotely over the Internet.
      // It is really cool. Why can't the other middleware runtimes follow
      // the simplicity of PHP to do such things.
      // Instantiate the PHP SOAP client library by pointing directly to
      // remote WSDL URL.
      $proxy = new SoapClient($wsdl, array("trace"=>1,"exceptions"=>0));
      // Set the required input parameter for the remote service.
      // In our case, it is just the ticker symbol. 
      $param['symbol'] = $tickerSymbol;  
      // Execute the remote logic. It is that simple.
      $result = $proxy->GetQuote($param); 
      // You have the XML-based response string now.
      $quoteResult = $result->GetQuoteResult;
      
      // Convert the XML formatted string into a DOM object.
      // PHP also does XML processing so elegantly and simply.
      $xml = simplexml_load_string($quoteResult);
      $stockPrice = 0.0;
      
      // The XML-based stock quote response is somewhat elaborative.
      // It contains information about different aspects of the given stock.
      // We are interested only in the current market price of that stock.
      // That information is available as: <Stock>...<Last>56.34</Last>...</Stock>
      // All we have to do is just parse the value of the <Last> XML element.
      // See for yourself how easy it is to do this in PHP.
      if (property_exists($xml, "Stock") == true) {
         // We have the <Stock> element in the Web service response.
         $stockInfo = $xml->Stock;
         
         // Now, check if the <Stock> element contains a child named <Last>.
         if (property_exists($stockInfo, "Last")) {
            // Just retrieve the last market price of this stock.
            $stockPrice = $stockInfo->Last;
         } else {
            $finalResult["ResultCode"] = 1;
            $finalResult["ResultMsg"] = 
               "Unable to get current stock price of " .
               "$accountHolderName's stock $tickerSymbol.";
            return($finalResult);            
         } // End of if (property_exists($stockInfo, "Last"))
      } else {
         $finalResult["ResultCode"] = 1;
         $finalResult["ResultMsg"] = 
            "Unable to get current stock price of " .
            "$accountHolderName's stock $tickerSymbol.";
         return($finalResult);         
      } // End of if (property_exists($xml, "Stock") == true)
   
      // Now that we have the current stock price, compute the
      // portfolio value and update it in the DB.
      // Return the result to the caller of this function.
      $finalResult = portfolioValue($accountHolderName, $stockPrice);
      return($finalResult);
   } // End of function getStockPortfolioValue   
?>