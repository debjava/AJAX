package coreservlets.client;

import com.google.gwt.core.client.*;
import com.google.gwt.user.client.ui.*;

public class GWTTestApp implements EntryPoint {
  private HTML randomNumberResult;
  private ListBox stateList, cityList;
  
  public void onModuleLoad() {
    Button randomNumberButton = new Button("Show Random Number");
    randomNumberResult = new HTML("<i>Num will go here</i>");
    stateList = new ListBox();
    populateStateList(stateList);
    stateList.setVisibleItemCount(1);
    cityList = new ListBox();
    cityList.addItem("Select City");
    cityList.setVisibleItemCount(1);
    cityList.setEnabled(false);
   
    randomNumberButton.addClickListener(new RanNumListener());
    stateList.addChangeListener(new StateListener());
    
    RootPanel.get("randomNumberButton").add(randomNumberButton);
    RootPanel.get("randomNumberResult").add(randomNumberResult);
    RootPanel.get("stateList").add(stateList);
    RootPanel.get("cityList").add(cityList);
  }
  
  private void populateStateList(ListBox stateList) {
    stateList.addItem("Select State");
    StateInfo[] nearbyStates = 
      StateInfo.getNearbyStates();
    for(int i=0; i<nearbyStates.length; i++) {
      String stateName =
        nearbyStates[i].getStateName();
      stateList.addItem(stateName);
    }
  }
  
  private class RanNumListener implements ClickListener {
    public void onClick(Widget sender) {
      randomNumberResult.setText("Number: " + Math.random()*10);
    }
  }
  
  private class StateListener implements ChangeListener {
    public void onChange(Widget sender) {
      int index = stateList.getSelectedIndex();
      String state = stateList.getItemText(index);
      StateInfo[] nearbyStates =
        StateInfo.getNearbyStates();
      String[] cities = 
        StateInfo.findCities(nearbyStates, state);
      cityList.clear();
      for(int i=0; i<cities.length; i++) {
        cityList.addItem(cities[i]);
      }
      cityList.setEnabled(true);
    }
  }
}

