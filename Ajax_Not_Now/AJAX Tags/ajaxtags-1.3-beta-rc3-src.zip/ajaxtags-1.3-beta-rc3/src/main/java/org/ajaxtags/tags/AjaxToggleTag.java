/**
 * Copyright 2005 Darren L. Spurgeon
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.tags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;

/**
 * Tag handler for the toggle (on/off, true/false) AJAX tag.
 * 
 * @author Darren Spurgeon
 * @version $Revision: 1.3 $ $Date: 2007/06/20 20:55:56 $ $Author: jenskapitza $
 */
public class AjaxToggleTag extends TagSupport {

	private String var;

	private String attachTo;

	private String baseUrl;

	private String parameters;

	private String source;

	private String ratings;

	private String defaultRating;

	private String state;

	private String onOff;

	private String containerClass;

	private String messageClass;

	private String selectedClass;

	private String selectedOverClass;

	private String selectedLessClass;

	private String overClass;

	private String preFunction;

	private String postFunction;

	private String errorFunction;

	private String parser;
	
	private String updateFunction;
	public String getUpdateFunction() {
		return updateFunction;
	}
	public void setUpdateFunction(String updateFunction) {
		this.updateFunction = updateFunction;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getContainerClass() {
		return containerClass;
	}

	public void setContainerClass(String containerClass) {
		this.containerClass = containerClass;
	}

	public String getDefaultRating() {
		return defaultRating;
	}

	public void setDefaultRating(String defaultRating) {
		this.defaultRating = defaultRating;
	}

	public String getErrorFunction() {
		return errorFunction;
	}

	public void setErrorFunction(String errorFunction) {
		this.errorFunction = errorFunction;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getMessageClass() {
		return messageClass;
	}

	public void setMessageClass(String messageClass) {
		this.messageClass = messageClass;
	}

	public String getOnOff() {
		return onOff;
	}

	public void setOnOff(String onOff) {
		this.onOff = onOff;
	}

	public String getOverClass() {
		return overClass;
	}

	public void setOverClass(String overClass) {
		this.overClass = overClass;
	}

	public String getParameters() {
		return parameters;
	}

	public void setParameters(String parameters) {
		this.parameters = parameters;
	}

	public String getParser() {
		return parser;
	}

	public void setParser(String parser) {
		this.parser = parser;
	}

	public String getPostFunction() {
		return postFunction;
	}

	public void setPostFunction(String postFunction) {
		this.postFunction = postFunction;
	}

	public String getPreFunction() {
		return preFunction;
	}

	public void setPreFunction(String preFunction) {
		this.preFunction = preFunction;
	}

	public String getRatings() {
		return ratings;
	}

	public void setRatings(String ratings) {
		this.ratings = ratings;
	}

	public String getSelectedClass() {
		return selectedClass;
	}

	public void setSelectedClass(String selectedClass) {
		this.selectedClass = selectedClass;
	}

	public String getSelectedLessClass() {
		return selectedLessClass;
	}

	public void setSelectedLessClass(String selectedLessClass) {
		this.selectedLessClass = selectedLessClass;
	}

	public String getSelectedOverClass() {
		return selectedOverClass;
	}

	public void setSelectedOverClass(String selectedOverClass) {
		this.selectedOverClass = selectedOverClass;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getVar() {
		return var;
	}

	public void setVar(String var) {
		this.var = var;
	}

	public String getAttachTo() {
		return attachTo;
	}

	public void setAttachTo(String attachTo) {
		this.attachTo = attachTo;
	}

	@Override
	public int doStartTag() throws JspException {
		// Required Properties
		this.baseUrl = (String) ExpressionEvaluatorManager.evaluate("baseUrl",
				this.baseUrl, String.class, this, super.pageContext);
		this.source = (String) ExpressionEvaluatorManager.evaluate("source",
				this.source, String.class, this, super.pageContext);
		this.ratings = (String) ExpressionEvaluatorManager.evaluate("ratings",
				this.ratings, String.class, this, super.pageContext);
		this.containerClass = (String) ExpressionEvaluatorManager.evaluate(
				"containerClass", this.containerClass, String.class, this,
				super.pageContext);
		this.selectedClass = (String) ExpressionEvaluatorManager.evaluate(
				"selectedClass", this.selectedClass, String.class, this,
				super.pageContext);
		this.selectedOverClass = (String) ExpressionEvaluatorManager.evaluate(
				"selectedOverClass", this.selectedOverClass, String.class,
				this, super.pageContext);
		this.selectedLessClass = (String) ExpressionEvaluatorManager.evaluate(
				"selectedLessClass", this.selectedLessClass, String.class,
				this, super.pageContext);
		this.overClass = (String) ExpressionEvaluatorManager.evaluate(
				"overClass", this.overClass, String.class, this,
				super.pageContext);

		// Optional Properties
		if (this.var != null) {
			this.var = (String) ExpressionEvaluatorManager.evaluate("var",
					this.var, String.class, this, super.pageContext);
		}
		if (this.attachTo != null) {
			this.attachTo = (String) ExpressionEvaluatorManager.evaluate(
					"attachTo", this.attachTo, String.class, this,
					super.pageContext);
		}
		if (this.messageClass != null) {
			this.messageClass = (String) ExpressionEvaluatorManager.evaluate(
					"messageClass", this.messageClass, String.class, this,
					super.pageContext);
		}
		if (this.parameters != null) {
			this.parameters = (String) ExpressionEvaluatorManager.evaluate(
					"parameters", this.parameters, String.class, this,
					super.pageContext);
		}
		if (this.state != null) {
			this.state = (String) ExpressionEvaluatorManager.evaluate("state",
					this.state, String.class, this, super.pageContext);
		}
		if (this.onOff != null) {
			this.onOff = (String) ExpressionEvaluatorManager.evaluate("onOff",
					this.onOff, String.class, this, super.pageContext);
		}
		if (this.defaultRating != null) {
			this.defaultRating = (String) ExpressionEvaluatorManager.evaluate(
					"defaultRating", this.defaultRating, String.class, this,
					super.pageContext);
		}
		if (this.preFunction != null) {
			this.preFunction = (String) ExpressionEvaluatorManager.evaluate(
					"preFunction", this.preFunction, String.class, this,
					super.pageContext);
		}
		if (this.postFunction != null) {
			this.postFunction = (String) ExpressionEvaluatorManager.evaluate(
					"postFunction", this.postFunction, String.class, this,
					super.pageContext);
		}
		if (this.errorFunction != null) {
			this.errorFunction = (String) ExpressionEvaluatorManager.evaluate(
					"errorFunction", this.errorFunction, String.class, this,
					super.pageContext);
		}

		return SKIP_BODY;
	}

	@Override
	public int doEndTag() throws JspException {
		OptionsBuilder options = new OptionsBuilder();
		options.add("source", this.source, true).add("ratings", this.ratings,
				true).add("containerClass", this.containerClass, true).add(
				"selectedClass", this.selectedClass, true).add(
				"selectedOverClass", this.selectedOverClass, true).add(
				"selectedLessClass", this.selectedLessClass, true).add(
				"overClass", this.overClass, true);

		if (this.messageClass != null)
			options.add("messageClass", this.messageClass, true);
		if (this.parameters != null)
			options.add("parameters", this.parameters, true);
		if (this.state != null)
			options.add("state", this.state, true);
		if (this.onOff != null)
			options.add("onOff", this.onOff, true);
		if (this.defaultRating != null)
			options.add("defaultRating", this.defaultRating, true);
		if (this.preFunction != null)
			options.add("preFunction", this.preFunction, false);
		if (this.postFunction != null)
			options.add("postFunction", this.postFunction, false);
		if (this.errorFunction != null)
			options.add("errorFunction", this.errorFunction, false);
		if (this.parser != null)
			options.add("parser", this.parser, false);
		if (this.updateFunction != null)
			options.add("updateFunction", this.updateFunction, false);
		
		StringBuffer script = new StringBuffer();
		// write opening div
		script.append("<div id=\"").append(this.source).append("\" class=\"")
				.append(this.containerClass);
		if (this.onOff != null && "true".equalsIgnoreCase(this.onOff)) {
			script.append(" onoff");
		}
		script.append("\">");
		// write links
		if (BooleanUtils.toBoolean(this.onOff)) {
			if (StringUtils.isNotBlank(this.defaultRating)
					&& StringUtils.isNotBlank(this.ratings)
					&& this.defaultRating.equalsIgnoreCase(this.ratings
							.split(",")[0])) {
				script.append("<a href=\"javascript:void(0)\" title=\"")
						.append(this.ratings.split(",")[0]).append(
								"\" class=\"").append(this.selectedClass)
						.append("\"></a>");
			} else {
				script.append("<a href=\"javascript:void(0)\" title=\"")
						.append(this.ratings.split(",")[1]).append("\"></a>");
			}
		} else {
			boolean ratingMatch = false;
			String[] ratingValues = this.ratings.split(",");
			for (int i = 0; i < ratingValues.length; i++) {
				String val = ratingValues[i];
				if (StringUtils.isBlank(this.defaultRating)
						|| ratingMatch == true) {
					script.append("<a href=\"javascript:void(0)\" title=\"")
							.append(val).append("\"></a>");
				} else if (ratingMatch == false
						|| this.defaultRating.equalsIgnoreCase(val)) {
					script.append("<a href=\"javascript:void(0)\" title=\"")
							.append(val).append("\" class=\"").append(
									this.selectedClass).append("\"></a>");
					if (this.defaultRating.equalsIgnoreCase(val))
						ratingMatch = true;
				}
			}
		}
		script.append("</div>\n");

		// write script
		script.append("<script type=\"text/javascript\">\n");

		if (StringUtils.isNotEmpty(this.attachTo)) {
			script.append(this.attachTo).append(".");
			if (StringUtils.isNotEmpty(this.var)) {
				script.append(this.var);
			} else {
				script.append("aj_").append(this.source);
			}
		} else if (StringUtils.isNotEmpty(this.var)) {
			script.append("var ").append(this.var);
		} else {
			script.append("var aj_").append(this.source);
		}

		script.append(" = new AjaxJspTag.Toggle(\n").append("\"").append(
				this.baseUrl).append("\", {\n").append(options.toString())
				.append("});\n").append("</script>\n\n");

		JspWriter writer = pageContext.getOut();
		try {
			writer.println(script);
		} catch (IOException e) {
			throw new JspException(e.getMessage());
		}
		return EVAL_PAGE;
	}

	@Override
	public void release() {
		this.var = null;
		this.attachTo = null;
		this.baseUrl = null;
		this.parameters = null;
		this.source = null;
		this.ratings = null;
		this.defaultRating = null;
		this.state = null;
		this.onOff = null;
		this.containerClass = null;
		this.messageClass = null;
		this.selectedClass = null;
		this.selectedOverClass = null;
		this.selectedLessClass = null;
		this.overClass = null;
		this.preFunction = null;
		this.postFunction = null;
		this.errorFunction = null;
		this.parser = null;
		super.release();
	}
}
