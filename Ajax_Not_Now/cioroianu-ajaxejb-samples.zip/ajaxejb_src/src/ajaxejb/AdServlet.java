package ajaxejb;

import javax.ejb.EJB;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.http.*;

public class AdServlet extends HttpServlet {

    @EJB(name="AdSession")
    private AdSession adSession;

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response) throws ServletException,
                                                           IOException {
        String userInput = request.getParameter("userInput");
        AdEntity adEntity = adSession.selectAd(userInput);
        request.setAttribute("adEntity", adEntity);
        response.setHeader("Cache-Control", "no-cache");
        response.setContentType("text/xml");
        request.getRequestDispatcher("/AdResponse.jsp").include(request, response);
    }
    
}
