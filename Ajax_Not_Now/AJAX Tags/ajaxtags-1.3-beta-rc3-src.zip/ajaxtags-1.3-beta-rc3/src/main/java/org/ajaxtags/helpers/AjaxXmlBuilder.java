/**
 * Copyright 2005 Darren L. Spurgeon
 * Copyright 2007 Jens Kapitza
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.helpers;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;

import org.apache.commons.beanutils.BeanUtils;

/**
 * Helper class to build valid XML typically returned in a response to the
 * client.
 * 
 * @author Darren Spurgeon
 * @author Jens Kapitza
 * @version $Revision: 1.4 $ $Date: 2007/06/20 20:52:58 $ $Author: jenskapitza $
 */
public final class AjaxXmlBuilder extends BaseXmlBuilder<Item> {

	/**
	 * Add item to XML.
	 * 
	 * @param name
	 *            The name of the item
	 * @param value
	 *            The value of the item
	 * @return
	 */
	public AjaxXmlBuilder addItem(String key, String value) {
		return addItem(key, value, false);
	}

	/**
	 * Add item wrapped with inside a CDATA element.
	 * 
	 * @param name
	 *            The name of the item
	 * @param value
	 *            The value of the item
	 * @return
	 */
	public AjaxXmlBuilder addItemAsCData(String key, String value) {
		return addItem(key, value, true);
	}

	/**
	 * Add items from a collection.
	 * 
	 * @param collection
	 * @param nameProperty
	 * @param valueProperty
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public AjaxXmlBuilder addItems(Collection<?> collection,
			String nameProperty, String valueProperty)
			throws IllegalAccessException, InvocationTargetException,
			NoSuchMethodException {
		return addItems(collection, nameProperty, valueProperty, false);
	}

	/**
	 * Add item to XML.
	 * 
	 * @param name
	 *            The name of the item
	 * @param value
	 *            The value of the item
	 * @param asCData
	 *            add as CData
	 * @return
	 */
	public AjaxXmlBuilder addItem(String name, String value, boolean asCData) {
		add(new Item(name, value, asCData));
		return this;
	}

	/**
	 * Add items from a collection.
	 * 
	 * @param collection
	 * @param nameProperty
	 * @param valueProperty
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public AjaxXmlBuilder addItems(Collection<?> collection,
			String nameProperty, String valueProperty, boolean asCData)
			throws IllegalAccessException, InvocationTargetException,
			NoSuchMethodException {
		for (Object element : collection) {
			String name = BeanUtils.getProperty(element, nameProperty);
			String value = BeanUtils.getProperty(element, valueProperty);
			addItem(name, value, asCData);
		}
		return this;
	}

	@Override
	protected String getXMLString() {
		StringBuffer xml = new StringBuffer();
		xml.append("<ajax-response>");
		xml.append("<response>");
		for (Item item : getItems()) {
			xml.append("<item>");
			xml.append("<name>");
			if (item.isAsCData()) {
				xml.append("<![CDATA[");
			}
			xml.append(item.getName());
			if (item.isAsCData()) {
				xml.append("]]>");
			}
			xml.append("</name>");
			xml.append("<value>");
			if (item.isAsCData()) {
				xml.append("<![CDATA[");
			}
			xml.append(item.getValue());
			if (item.isAsCData()) {
				xml.append("]]>");
			}
			xml.append("</value>");
			xml.append("</item>");
		}
		xml.append("</response>");
		xml.append("</ajax-response>");

		return xml.toString();

	}

}
