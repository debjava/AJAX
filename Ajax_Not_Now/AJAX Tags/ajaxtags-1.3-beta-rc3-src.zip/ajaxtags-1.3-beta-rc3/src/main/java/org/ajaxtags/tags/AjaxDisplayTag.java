/**
 * Copyright 2005 Darren L. Spurgeon
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.tags;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.jsp.JspException;

import org.ajaxtags.helpers.AjaxHtmlHelper;
import org.apache.commons.lang.StringUtils;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;

import au.id.jericho.lib.html.Attribute;
import au.id.jericho.lib.html.Attributes;
import au.id.jericho.lib.html.Element;
import au.id.jericho.lib.html.HTMLElementName;
import au.id.jericho.lib.html.OutputDocument;
import au.id.jericho.lib.html.Segment;
import au.id.jericho.lib.html.Source;
import au.id.jericho.lib.html.StartTag;

/**
 * Wraps a DisplayTag (http://displaytag.org) table, enabling AJAX capabilities. In the process,
 * anchors in the navigation are rewritten on the fly so that the DisplayTag table refreshes within
 * the same region on the page without a full-page reload.
 *
 * @author Darren Spurgeon
 * @version $Revision: 1.2 $ $Date: 2007/06/20 20:55:56 $ $Author: jenskapitza $
 */
public class AjaxDisplayTag extends AjaxAreaTag {

  private String pagelinksClass = "pagelinks";
  private String tableClass = "displaytag";
  private String columnClass = "sortable";
  private String baseUrl = "";
  private String postFunction = null;
  private String parameters;

  /**
   * @return Returns the pagelinksClass.
   */
  public String getPagelinksClass() {
    return this.pagelinksClass;
  }

  /**
   * @param pagelinksClass The pagelinksClass to set.
   */
  public void setPagelinksClass(String pagelinksClass) {
    this.pagelinksClass = pagelinksClass;
  }

  /**
   * @return Returns the postFunction.
   */
   public String getPostFunction() {
      return postFunction;
   }

  /**
   * @param postFunction javascript function name to be called after the Ajax request.
   */
   public void setPostFunction(String postFunction) {
      this.postFunction = postFunction;
   }

  /**
   * @return Returns the tableClass.
   */
  public String getTableClass() {
    return this.tableClass;
  }

  /**
   * @param tableClass The tableClass to set.
   */
  public void setTableClass(String tableClass) {
    this.tableClass = tableClass;
  }

  /**
   * @return Returns the columnClass.
   */
  public String getColumnClass() {
    return this.columnClass;
  }

  /**
   * @param columnClass The columnClass to set.
   */
  public void setColumnClass(String columnClass) {
    this.columnClass = columnClass;
  }

  /**
   * @return Returns the baseUrl.
   */
  public String getBaseUrl() {
    return this.baseUrl;
  }

  /**
   * @param baseUrl The baseUrl to set.
   */
  public void setBaseUrl(String baseUrl) {
    this.baseUrl = baseUrl;
  }

  public String getParameters() {
      return parameters;
    }

    public void setParameters(String parameters) {
      this.parameters = parameters;
    }

  /**
   * @see javax.servlet.jsp.tagext.Tag#release()
   */
    @Override
  public void release() {
    this.pagelinksClass = null;
    this.tableClass = null;
    this.columnClass = null;
    this.baseUrl = null;
    this.postFunction = null;
    this.parameters = null;
    super.release();
  }

  /**
   * @see org.ajaxtags.tags.AjaxAreaTag#initParameters()
   */
    @Override
  protected void initParameters() throws JspException {
    super.initParameters();
    // Optional Properties
    if (this.pagelinksClass != null) {
      this.pagelinksClass = (String) ExpressionEvaluatorManager.evaluate(
          "pagelinksClass", this.pagelinksClass, String.class, this, super.pageContext);
    }
    if (this.tableClass != null) {
      this.tableClass = (String) ExpressionEvaluatorManager.evaluate(
          "tableClass", this.tableClass, String.class, this, super.pageContext);
    }
    if (this.columnClass != null) {
      this.columnClass = (String) ExpressionEvaluatorManager.evaluate(
          "columnClass", this.columnClass, String.class, this, super.pageContext);
    }
    if (this.baseUrl != null) {
      this.baseUrl = (String) ExpressionEvaluatorManager.evaluate(
          "baseUrl", this.baseUrl, String.class, this, super.pageContext);
    }
    if (this.postFunction != null) {
      this.postFunction = (String) ExpressionEvaluatorManager.evaluate("postFunction",
          this.postFunction, String.class, this, super.pageContext);
    }
    if (this.parameters != null) {
        this.parameters = (String) ExpressionEvaluatorManager.evaluate("parameters", this.parameters,
                String.class, this, super.pageContext);
    }
  }

  /**
   * @see org.ajaxtags.tags.AjaxAreaTag#processContent(java.lang.String)
   */
    @Override
  protected String processContent(String content) {
        Source source = new Source(content);
    OutputDocument outputDocument = new OutputDocument(source);
    // Rewrite pagination links
    List<?> spans = source.findAllElements(HTMLElementName.SPAN);
    for (Iterator<?> spanIter = spans.iterator(); spanIter.hasNext();) {
      Element spanElement = (Element) spanIter.next();
      Attributes spanAttributes = spanElement.getAttributes();
      Attribute classAttribute = spanAttributes.get("class");
      if (classAttribute != null
          && classAttribute.getValue() != null
          && classAttribute.getValue().equalsIgnoreCase(this.pagelinksClass)) {
        rewriteAnchors(spanElement, outputDocument);
      }
    }
    // Rewrite Column sorting links
    List<?> tables = source.findAllElements(HTMLElementName.TABLE);
    for (Iterator<?> tableIter = tables.iterator(); tableIter.hasNext();) {
      Element tableElement = (Element) tableIter.next();
      Attributes tableAttributes = tableElement.getAttributes();
      Attribute classAttribute = tableAttributes.get("class");
      if (classAttribute != null
          && classAttribute.getValue() != null
          && classAttribute.getValue().equalsIgnoreCase(this.tableClass)) {
        List<?> theads = tableElement.findAllElements(HTMLElementName.THEAD);
        for (Iterator<?> theadIter = theads.iterator(); theadIter.hasNext();) {
          Element theadElement = (Element) theadIter.next();
          if (StringUtils.isNotBlank(this.columnClass)) {
            List<?> ths = theadElement.findAllElements(HTMLElementName.TH);
            for (Iterator<?> thIter = ths.iterator(); thIter.hasNext();) {
              Element columnElement = (Element) thIter.next();
              Attribute columnClassAttribute = columnElement.getAttributes().get("class");
              if (columnClassAttribute != null
                  && columnClassAttribute.getValue() != null
                  && StringUtils
                      .contains(columnClassAttribute.getValue().toLowerCase(), this.columnClass
                          .toLowerCase())) {
                rewriteAnchors(columnElement, outputDocument);
              }
            }
          } else {
            rewriteAnchors(theadElement, outputDocument);
          }
        }
      }
    }

    return outputDocument.toString();
  }

  /**
   * Rewrite all anchors in this segment.
   *
   * @param segment
   * @param outputDocument
   */
  @SuppressWarnings("unchecked")
protected void rewriteAnchors(Segment segment, OutputDocument outputDocument) {
    List<?> anchors = segment.findAllStartTags(HTMLElementName.A);
    for (Iterator<?> i = anchors.iterator(); i.hasNext();) {
      StartTag anchorTag = (StartTag) i.next();
      Attributes attributes = anchorTag.getAttributes();
      Attribute hrefAttribute = attributes.get("href");
      if (hrefAttribute == null)
        continue;
      String href = hrefAttribute.getValue();
      if (href == null)
        continue;
      // include the baseURL so it loads the exact page with the table on it
      if (StringUtils.isNotBlank(this.getBaseUrl())) {
        // Remove url, we are going to use baseUrl.
        if (href.indexOf("?") > 0) {
          href = href.substring(href.indexOf("?"));
        }
        href = this.getBaseUrl() + href;
      }
      
      Map<String, String> attrreplace = outputDocument.replace(attributes, true);
    //  AttributesOutputSegment outputSegment = new AttributesOutputSegment(attributes, true);
      OptionsBuilder onclickOptions = new OptionsBuilder();
      if (this.postFunction != null) {
        onclickOptions.add("onComplete", this.postFunction, false);
      }
      if (this.parameters != null) {
          onclickOptions.add("parameters", this.parameters, true);
      }
      attrreplace.put("href", "javascript://nop/");
      attrreplace.put("onclick",
          AjaxHtmlHelper.getOnclickAjax(this.getId(), href, this.getAjaxFlag(), onclickOptions));
     // outputDocument.add(outputSegment);
    }
  }

}
