/**
 * Copyright 2007 Jens Kapitza
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.ajaxtags.helpers;

import java.util.ArrayList;
import java.util.List;

/**
 * Helper class to build valid XML as a base for all xmlbuilder
 * 
 * @author Jens Kapitza
 * @version $Revision: 1.5 $ $Date: 2007/06/20 20:55:57 $ $Author: jenskapitza $
 * @param <V>
 *            Listtype (Item, TreeItem)
 */
abstract class BaseXmlBuilder<V> extends ArrayList<V> {
	/**
	 * default encoding is utf-8
	 */
	private String encoding = "UTF-8";

	/**
	 * 
	 * @return the xml encoding
	 */
	public String getEncoding() {
		return encoding;
	}

	/**
	 * set the xml encoding
	 * 
	 * @param encoding
	 */
	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	/**
	 * 
	 * @return the item list
	 */
	protected List<V> getItems() {
		return this;
	}

	/**
	 * 
	 * @return the xml body, xml encoding is added by {@link #toString()}
	 */
	protected abstract String getXMLString();

	/**
	 * return the full XML ducument
	 */
	@Override
	public String toString() {
		StringBuffer xml = new StringBuffer().append("<?xml version=\"1.0\"");
		if (getEncoding() != null) {
			xml.append(" encoding=\"");
			xml.append(getEncoding());
			xml.append("\"");
		}
		xml.append(" ?>");
		xml.append(getXMLString());

		return xml.toString();
	}

}
