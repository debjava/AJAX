package ajaxejb;

import java.util.List;

import java.util.Random;
import java.util.StringTokenizer;

import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless(name="AdSession")
public class AdSessionBean implements AdSession {
    @PersistenceContext(unitName="ajaxejb")
    private EntityManager em;

    public AdSessionBean() {
    }

    public Object mergeEntity(Object entity) {
        return em.merge(entity);
    }

    public Object persistEntity(Object entity) {
        em.persist(entity);
        return entity;
    }

    /** <code>select o from AdEntity o</code> */
    public List<AdEntity> queryAdEntityFindAll() {
        return em.createNamedQuery("AdEntity.findAll").getResultList();
    }

    public void removeAdEntity(AdEntity adEntity) {
        adEntity = em.find(AdEntity.class, adEntity.getKeyword());
        em.remove(adEntity);
    }

    public AdEntity selectAd(String userInput) {
        String keyword = "nothing";
        if (userInput != null && userInput.length() > 0) {
            StringTokenizer st = new StringTokenizer(
                userInput, ",.?!'& \t\n\r\f");
            int n = st.countTokens();
            if (n > 0) {
                int k = new Random().nextInt(n);
                for (int i = 0; i < k; i++)
                    st.nextToken();
                keyword = st.nextToken();
            }
        }
        AdEntity ad = new AdEntity();
        ad.setKeyword(keyword);
        ad.setUrl(keyword + ".com");
        ad.setContent("Buy " + keyword + " from " + ad.getUrl());
        return ad;
    }
}
