package org.ajaxtags.demo.servlet;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.ajaxtags.helpers.ValueListXmlBuilder;
import org.ajaxtags.servlets.BaseAjaxServlet;

public class CallBackTime extends BaseAjaxServlet {

	private static class Helper {

		private List<CallBackTime> it = new ArrayList<CallBackTime>();

		public Helper() {
		}

		public synchronized void add(CallBackTime t) {
			if (!it.contains(t))
				it.add(t);
			try {
				Thread.sleep(4000);
				System.out.println(it.size() + " L");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		public synchronized void remove(CallBackTime t) {
//			it.remove(t);
		}

	}

	private static Helper h;
	static {
		h = new Helper();
	}

	public String getXmlContent(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		System.out.println("catch Client");
		h.add(this);
		h.remove(this);
		System.out.println("release Client");
		ValueListXmlBuilder xml = new ValueListXmlBuilder();
		xml.addItem("datum", new Date().toString(), "true");

		return xml.toString();

	}
}
