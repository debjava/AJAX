function createRequest(method, url, callback) {
    var request;
    if (window.XMLHttpRequest)
        request = new XMLHttpRequest();
    else if (window.ActiveXObject)
        request = new ActiveXObject("Microsoft.XMLHTTP");
    else
        return null;

    request.open(method, url, true);

    function calbackWrapper() {
        callback(request);
    }
    request.onreadystatechange = calbackWrapper;

    return request;
}

function deleteRequest(request) {
    function doNothing() {
    }
    request.onreadystatechange = doNothing;
    request.abort();
    delete request;
}

var debug = true;

function adUpdate(request) {
    if (request.readyState == 4) {
        if (request.status == 200) {
            var adSection = document.getElementById("ad");
                        adSection.innerHTML = request.responseText;
        } else if (debug) {
            if (request.statusText)
                alert(request.statusText);
            else
                alert("HTTP Status: " + request.status);
                }
    }
}

function getUserInput() {
    var userInput = "";
    var forms = document.forms;
    for (var i = 0; i < forms.length; i++) {
        var elems = forms[i].elements;
        for (j = 0; j < elems.length; j++) {
            var elemType = elems[j].type.toLowerCase();
            if (elemType == "text" || elemType == "textarea") {
                var elemValue = elems[j].value;
                userInput += " " + elemValue;
            }
        }
    }
    return userInput;
}

var adURL = "../adservlet"
var adRequest = null;

function sendAdRequest() {
    if (adRequest)
        deleteRequest(adRequest);
        var url = adURL + "?userInput=" + escape(getUserInput());
    adRequest = createRequest("GET", url, adUpdate);
    adRequest.send(null);
}

function init() {
        sendAdRequest();
    setInterval("sendAdRequest()", 1000);
}
