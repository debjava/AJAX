package com.oreilly.ajax;

public class AjaxTagsTabSupport
{
 

}
